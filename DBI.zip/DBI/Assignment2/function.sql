
-- function to calculate total amount of an order
CREATE FUNCTION total_amount(@order_id INT)
RETURNS DECIMAL(10,2)
AS
BEGIN
	DECLARE @total DECIMAL(10, 2) = 0.00

	SET @total = (

		SELECT
			SUM(price)
		FROM
			OrderDetails OD JOIN Tickets T ON OD.Ticket_ID = T.Ticket_ID 
		WHERE	
			OD.order_id = @order_id
	
	)
	RETURN @total;
END;


-- test
SELECT dbo.total_amount(1)
SELECT dbo.total_amount(3)