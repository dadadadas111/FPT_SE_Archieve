WITH ProductCount as (

SELECT    ProductSubcategory.SubcategoryID,
		ProductSubcategory.Name AS SubcategoryName,
		ProductSubcategory.Category,
		COUNT(distinct ProductID) as NumberOfProducts
FROM         Product RIGHT JOIN
                      ProductSubcategory ON Product.SubcategoryID = ProductSubcategory.SubcategoryID
GROUP BY
	ProductSubcategory.SubcategoryID,
		ProductSubcategory.Name,
		ProductSubcategory.Category
)

SELECT * 
FROM ProductCount
WHERE NumberOfProducts = (SELECT MIN (NumberOfProducts) FROM ProductCount)