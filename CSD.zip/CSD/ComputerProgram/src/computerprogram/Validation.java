/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computerprogram;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Validation {

    static int enterChoice() {
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        // loop if choice not in range [1,3]
        while (choice < 1 || choice > 3) {
            System.out.print("Please choice one option:");
            try {
                choice = Integer.parseInt(sc.nextLine());
                // check if choice is not in range [1, 3]
                if (choice < 1 || choice > 3) {
                    throw new Exception();
                }
            } catch (Exception e) {
                System.out.println("Invalid choice. Try again");
            }
        }
        return choice;
    }

    static double enterDouble(String msg) {
        Scanner sc = new Scanner(System.in);
        double value = Double.NaN;

        // loop if value is NaN
        while (Double.isNaN(value)) {
            System.out.print(msg);
            try {
                value = Double.parseDouble(sc.nextLine());
            } catch (Exception e) {
                System.out.println("Please input number");
            }
        }
        return value;
    }

    static String enterOperator(String msg) {
        Scanner sc = new Scanner(System.in);
        String Op = "";
        // loop if check operator return false
        do {
            System.out.print(msg);
            Op = sc.nextLine().trim();
        } while (!checkOperator(Op));
        return Op;
    }

    static int enterPositiveInt(String msg) {
        Scanner sc = new Scanner(System.in);
        int value = -1;
        // loop while value is not positive
        while (value <= 0){
            System.out.print(msg);
            try {
                value = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.println("BMI is digit");
            }
        }
        return value;
    }

    private static boolean checkOperator(String Op) {
        switch (Op) {
            case "+":
            case "-":
            case "*":
            case "/":
            case "^":
            case "=":
                return true;
            default:
                System.out.println("Please input (+, -, *, /, ^)");
                return false;
        }
    }

}
