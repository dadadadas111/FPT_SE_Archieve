/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package candidatemanager;

/**
 *
 * @author asus
 */
public class Main {

    public static void main(String[] args) {
        
        Manager manager = new Manager();
        
        // endless loop
        while (true) {

            // Step 1. Display menu
            displayMenu();

            // Step 2. User enter choice
            int choice = enterChoice();

            // Step 3. Perform chosen function
            performFunction(manager, choice);
        }

    }

    private static void displayMenu() {
        
        System.out.println("=======================================");
        System.out.println("----- CANDIDATE MANAGEMENT SYSTEM -----\n"
                + "1. Experience\n"
                + "2. Fresher\n"
                + "3. Internship\n"
                + "4. Searching\n"
                + "5. Exit");
    }

    private static int enterChoice() {
        return Validation.enterInt("Please choose an option: ", 1, 5);
    }

    private static void performFunction(Manager manager, int choice) {
        // check choice value
        switch (choice) {
            case 1:
                manager.createExperience();
                break;
            case 2:
                manager.createFresher();
                break;
            case 3:
                manager.createInternship();
                break;
            case 4:
                manager.search();
                break;
            case 5:
                System.exit(0);
                
        }
    }

}
