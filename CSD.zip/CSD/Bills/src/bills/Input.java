/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bills;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Input {

    static final Scanner sc = new Scanner(System.in);
    
    static int enterInt(String msg, int min, String errorMessage) {
        int value = min-1;
        // loop while value < min
        while (value < min){
            System.out.print(msg);
            try {
                value = Integer.parseInt(sc.nextLine());
                // check if value < min
                if (value < min){
                    System.out.println(errorMessage);
                }
            } catch (Exception e) {
                System.out.println("Input must be integer. Try again");
            }
        }
        return value;
    }

    static int enterPositiveInt(String msg) {
        return enterInt(msg, 1, "Input must be positive. Try again");
    }
    
}
