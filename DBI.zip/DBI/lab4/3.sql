--3
use abc;

SELECT *
FROM
	SanPham
WHERE
	TenVT LIKE '%GACH%'
	AND Giamua > 110;