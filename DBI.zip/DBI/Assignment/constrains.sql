
ALTER TABLE Customers
ADD CONSTRAINT UniqueEmail UNIQUE (Email);


ALTER TABLE Customers
ADD CONSTRAINT PhoneNumberCheck CHECK (PhoneNumber LIKE '[0-9]%');


-- ngay dat ve < 


-- test constrains
INSERT INTO Customers (CustomerID, Name, Email, PhoneNumber)
VALUES
    (21, 'Nguyen Van A', 'nguyenvana@email.com', '11123456789')



INSERT INTO Customers (CustomerID, Name, Email, PhoneNumber)
VALUES
    (21, 'Nguyen Van A', 'nguyenvanaaa@email.com', 'x11123456789')