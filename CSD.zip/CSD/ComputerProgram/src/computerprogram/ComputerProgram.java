/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computerprogram;

/**
 *
 * @author asus
 */
public class ComputerProgram {

    public static void main(String[] args) {

        // endless loop
        while (true) {

            // Step 1. Display menu
            displayMenu();

            // Step 2. User enter choice
            int choice = Validation.enterChoice();

            // Step 3. Perform chosen function
            performFunction(choice);
        }

    }

    public static void displayMenu() {
        System.out.println("========= Calculator Program =========\n"
                + "1. Normal Calculator\n"
                + "2. BMI Calculator \n"
                + "3. Exit ");
    }

    public static void performFunction(int choice) {
        switch (choice) {
            case 1:
                Calculator.process();
                break;
            case 2:
                BMICalculator.process();
                break;
            case 3:
                System.exit(0);

        }
    }

}
