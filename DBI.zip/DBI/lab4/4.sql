--4
use abc;

SELECT 
	HoaDon.MAHD, 
	CAST(Ngay AS date)NGAY, 
	TENKH, 
	DIACHI, 
	DT 
FROM
	HoaDon
	JOIN
	KhachHang
	ON HoaDon.MaKH = KhachHang.MaKH
ORDER BY
	Ngay;