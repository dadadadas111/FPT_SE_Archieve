package btree;
public class Node {
  int info;
  Node left,right;
  public Node(){
  }
  public Node(int info, Node left, Node right){
      this.info = info;
      this.left = left;
      this.right = right;
  }
  public Node(int info){
      this.info = info;
      left=null;
      right=null;
  }
  public void print(){
      System.out.print(" "+info);
  }
  
}
