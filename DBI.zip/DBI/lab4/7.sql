--7
use abc;

WITH TongHoaDon AS(
	SELECT
		MAHD,
		SUM(SL * GiaBan) AS TongGiaTri
	FROM
		ChiTietHoaDon
	GROUP BY
		MAHD
)

SELECT
	r1.MAHD,
	CAST(Ngay AS DATE)NGAY,
	r3.MAKH,
	TENKH,
	DIACHI,
	TongGiaTri
FROM
	TongHoaDon r1
	JOIN HoaDon r2 ON r1.MaHD = r2.MaHD
	JOIN KhachHang r3 ON r2.Makh = r3.MaKH
WHERE
	TongGiaTri = (
		SELECT MAX(TongGiaTri)
		FROM TongHoaDon
	)
