update ProductInventory
set Quantity = 2000
where ProductID in (

SELECT    Product.ProductID
FROM         Product INNER JOIN
                      ProductModel ON Product.ModelID = ProductModel.ModelID
WHERE     (Product.ModelID = 33)

)

