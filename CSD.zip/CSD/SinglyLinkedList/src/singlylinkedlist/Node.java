/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singlylinkedlist;

/**
 *
 * @author asus
 */
public class Node {

    int info;
    Node next;

    Node() {
        next = null;
    }

    ;

    public Node(int info) {
        this.info = info;
        next = null;
    }
    
    Node(int info, Node next) {
        this.info = info;
        this.next = next;
    }

    @Override
    public String toString() {
        return "Node{" + "info=" + info + ", next=" + next + '}';
    }
    

}
