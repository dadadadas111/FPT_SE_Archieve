

SELECT 
	e.EmployeeID,
	LastName + ' ' + FirstName AS FullName,
	j.JobTitle AS 'Current Job',
	j2.JobTitle AS 'History Job'
FROM
	Employees e
	JOIN Jobs j ON e.JobID = j.JobID
	JOIN JobHistory jh ON e.EmployeeID = jh.EmployeeID
	JOIN Jobs j2 ON j2.JobID = jh.JobID
ORDER BY
	EmployeeID DESC
