package heaps;

public class ArrayHeap {

    // Function that converts an array to a heap
    public static void makeHeap(int[] a) {
        int n = a.length;
        // Start from the last non-leaf position of the tree and perform the Heap
        for (int i = n / 2 - 1; i >= 0; i--) {
            heap(a, n, i);
        }
    }

    // The function executes the Heap at a specific node
    public static void heap(int[] a, int n, int i) {
        int largest = i; // Khởi tạo nút lớn nhất là i
        int left = 2 * i + 1; // left node
        int right = 2 * (i + 1); // right node
        // So sánh với nút con trái
        if (left < n && a[left] > a[largest]) {
            largest = left;
        }
        // Compare with the right child node
        if (right < n && a[right] > a[largest]) {
            largest = right;
        }
        // If the largest node is not the current node, swap places and continue the Heap
        if (largest != i) {
            int swap = a[i];
            a[i] = a[largest];
            a[largest] = swap;
            // Heap recursion with swapped child nodes
            heap(a, n, largest);
        }
    }

    // Prints the elements of the array
    public static void printArray(int[] a) {
        for (int x : a) {
            System.out.print(x + " ");
        }
        System.out.println();
    }

    public static void makeMinHeap(int[] a) {
        int n = a.length;
        // Start from the last non-leaf position of the tree and perform the Heap
        for (int i = n / 2 - 1; i >= 0; i--) {
            minheap(a, n, i);
        }
    }

    // The function executes the Heap at a specific node
    public static void minheap(int[] a, int n, int i) {
        int smallest = i; // Khởi tạo nút lớn nhất là i
        int left = 2 * i + 1; // left node
        int right = 2 * (i + 1); // right node
        // So sánh với nút con trái
        if (left < n && a[left] < a[smallest]) {
            smallest = left;
        }
        // Compare with the right child node
        if (right < n && a[right] < a[smallest]) {
            smallest = right;
        }
        
        // If the largest node is not the current node, swap places and continue the Heap
        if (smallest != i) {
            int swap = a[i];                  
            a[i] = a[smallest];
            a[smallest] = swap;
            // Heap recursion with swapped child nodes
            heap(a, n, smallest);
        }
    }

}
