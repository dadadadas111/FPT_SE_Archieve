package graph;

import java.io.RandomAccessFile;

public class Graph {

    final int MAX = 1000000;
    int[][] a;
    int[] P;
    int[] L;
    int n;
    char v[];
    int deg[];
    int X[];//using for Hamilton cycle
    int countHamilton;

    Graph() {
        v = "abcdefghi".toUpperCase().toCharArray();
        n = v.length;
        a = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = 0;
            }
        }
        a[0][1] = 0;
        a[0][2] = 1;
        a[0][3] = 1;
        a[1][0] = 1;
        a[1][4] = 1;
        a[2][0] = 1;
        a[2][5] = 1;
        a[3][0] = 1;
        a[3][6] = 1;
        a[4][1] = 1;
        a[4][7] = 1;
        a[5][2] = 1;
        a[5][7] = 1;
        a[6][3] = 1;
        a[6][7] = 1;
        a[7][4] = 1;
        a[7][5] = 1;
        a[7][6] = 1;
    }

    public void inputWeightedGraph() {
        n = 7;
        a = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = MAX;
            }
        }
        for (int i = 0; i < n; i++) {
            a[i][i] = 0;
        }
        a[0][1] = 1;
        a[0][2] = 3;
        a[0][3] = 4;
        a[1][2] = 1;
        a[1][4] = 5;
        a[2][4] = 5;
        a[2][5] = 2;
        a[2][6] = 4;
        a[3][2] = 7;
        a[3][5] = 6;
        a[4][6] = 7;
        a[5][6] = 5;
    }

    public void displayMatrix(int[][] a) {
        n = a.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (a[i][j] == MAX) {
                    System.out.print("\t.");
                } else {
                    System.out.print("\t" + a[i][j]);
                }
            }
            System.out.println("\n");
        }
    }

    int deg(int i) {
        int s;
        s = 0;
        for (int j = 0; j < n; j++) {
            s += a[i][j];
        }
        s += a[i][i];
        return (s);
    }

    void visit(int i) throws Exception {
        System.out.print("(" + i + "," + v[i] + ")");
    }

    void breadth(boolean[] en, int i) throws Exception {
        Queue q = new Queue();
        int r, j;
        q.enqueue(i);
        en[i] = true;
        while (!q.isEmpty()) {
            r = q.dequeue();
            visit(r);
            for (j = 0; j < n; j++) {
                if (!en[j] && a[r][j] > 0) {
                    q.enqueue(j);
                    en[j] = true;
                }
            }
        }
    }

    void breadth(int k) throws Exception {
        boolean[] en = new boolean[n];
        int i;
        for (i = 0; i < n; i++) {
            en[i] = false;
        }
        breadth(en, k);
        for (i = 0; i < n; i++) {
            if (!en[i]) {
                breadth(en, i);
            }
        }
    }

    void depth(boolean[] visited, int k) throws Exception {
        //visit(k);
        visited[k] = true;
        for (int i = 0; i < n; i++) {
            if (!visited[i] && a[k][i] > 0) {
                depth(visited, i);
            }
        }
    }
    
    
    
    int countConnected (int k) throws Exception {
        boolean[] visited = new boolean[n];
        int i;
        int count = 1;
        for (i = 0; i < n; i++) {
            visited[i] = false;
        }
        depth(visited, k);
        for (i = 0; i < n; i++) {
            if (!visited[i]) {
                depth(visited, i);
                count ++;
            }
        }
        return count;
    }

    void depth(int k) throws Exception {
        boolean[] visited = new boolean[n];
        int i;
        for (i = 0; i < n; i++) {
            visited[i] = false;
        }
        depth(visited, k);
        for (i = 0; i < n; i++) {
            if (!visited[i]) {
                depth(visited, i);
            }
        }
    }
    
    

    public void dijkstra(int s, int t) {
        int stop = 0, u = s, min = MAX;
        int set[] = new int[n];
        L = new int[n];
        P = new int[n];
        for (int v = 0; v < n; v++) {
            set[v] = 0;
        }
        set[s] = 1;
        L[s] = 0;
        P[s] = s;
        for (int v = 0; v < n; v++) {
            L[v] = a[s][v];
            P[v] = s;
        }
        while (stop == 0) {
            min = MAX;
            for (int v = 0; v < n; v++) {
                if (set[v] == 0 && min > L[v]) {
                    min = L[v];
                    u = v;
                }
            }
            set[u] = 1;
            for (int v = 0; v < n; v++) {
                if (set[v] == 0) {
                    if (L[v] > L[u] + a[u][v]) {
                        L[v] = L[u] + a[u][v];
                        P[v] = u;
                    }
                }
            }
            if (u == t) {
                stop = 1;
            }
        }
    }

    public String traceRoute(int s, int t) {
        int i = 0, k = t, path[];
        path = new int[n];
        while (k != s) {
            path[i] = k;
            k = P[k];
            i++;
        }
        String p = "";
        for (int j = i; j >= 0; j--) {
            p += v[path[j]];
            if (j > 0){
                p += " ";
            }
        }
        return p;
    }

    public void shortestPath(int s, int t) {
        dijkstra(s, t);
        traceRoute(s, t);
    }

    public void dijkstra(int s) {
        int stop = 0, u = s, min = MAX;
        int set[] = new int[n];
        L = new int[n];
        P = new int[n];
        for (int v = 0; v < n; v++) {
            set[v] = 0;
        }
        set[s] = 1;
        L[s] = 0;
        P[s] = s;
        for (int v = 0; v < n; v++) {
            L[v] = a[s][v];
            P[v] = s;
        }
        int count = 1;
        while (count < n) {
            min = MAX;
            for (int v = 0; v < n; v++) {
                if (set[v] == 0 && min > L[v]) {
                    min = L[v];
                    u = v;
                }
            }
            set[u] = 1;
            for (int v = 0; v < n; v++) {
                if (set[v] == 0) {
                    if (L[v] > L[u] + a[u][v]) {
                        L[v] = L[u] + a[u][v];
                        P[v] = u;
                    }
                }
            }
            count++;
        }
    }

    public void traceRoute(int s) {
        for (int t = 0; t < n; t++) {
            if (t != s) {
                traceRoute(s, t);
            }
        }
    }

    public void shortestPath(int s) {
        dijkstra(s);
        traceRoute(s);
    }

    public void floyd() {
        int L[][] = new int[n][n];
        int P[][] = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                L[i][j] = a[i][j];
                P[i][j] = i;
            }
        }
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (L[i][j] > L[i][k] + L[k][j]) {
                        L[i][j] = L[i][k] + L[k][j];
                        P[i][j] = k;
                    }
                }
            }
        }
        System.out.println("Floyd: Shortest path length matrix:\n");
        displayMatrix(L);
        System.out.println("Shortest path matrix:\n");
        displayMatrix(P);
    }

    public void inputEulerGraph() {
        v = "12345678".toCharArray();
        n = v.length;
        a = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = 0;
            }
        }
        a[0][1] = 1;
        a[0][2] = 1;
        a[1][0] = 1;
        a[1][2] = 1;
        a[2][0] = 1;
        a[2][1] = 1;
        a[2][3] = 1;
        a[2][4] = 1;
        a[3][2] = 1;
        a[3][5] = 1;
        a[4][2] = 1;
        a[4][5] = 1;
        a[5][3] = 1;
        a[5][4] = 1;
        a[5][6] = 1;
        a[5][7] = 1;
        a[6][5] = 1;
        a[6][7] = 1;
        a[7][5] = 1;
        a[7][6] = 1;
    }

    public boolean isEuler() {
        boolean ok = true;
        int i, dem;
        i = 0;
        while (ok && i < n) {
            dem = 0;
            for (int j = 0; j < n; j++) {
                if (a[i][j] == 1) {
                    dem = dem + 1;
                }
            }
            if (dem % 2 > 0) {
                return false;
            } else {
                i = i + 1;
            }
        }
        return ok;
    }

    public void eulerCycle() {
        int u, x, y, z;
        boolean ok;
        Node p = new Node();
        Stack S = new Stack();
        if (!isEuler()) {
            System.out.println("Graph is not Euler");
            return;
        }
        System.out.println("Graph is Euler");
        System.out.println("Euler cycle:");
        u = 0;
        S.push(u);
        while (!S.isEmpty()) {
            x = (int) S.peek();
            ok = true;
            y = 0;
            while (ok == true && y < n) {
                if (a[x][y] == 1) {
                    S.push(y);
                    ok = false;
                    a[x][y] = 2;
                    a[y][x] = 2;
                } else {
                    y = y + 1;
                }
            }
            if (ok) {
                z = (int) S.pop();
                System.out.print(" " + v[z]);
            }
        }
        System.out.println();
    }

    public void inputHamilton() {
        v = "01234".toCharArray();
        n = v.length;
        int[][] graph = {
            {0, 1, 1, 1, 0},
            {1, 0, 1, 0, 1},
            {1, 1, 0, 1, 0},
            {1, 0, 1, 0, 1},
            {0, 1, 0, 1, 0}
        };
        a = graph;
//        a=new int[n][n];
//        for(int i=0;i<n;i++)
//            for(int j=0;j<n;j++)a[i][j]=0;
//        a[0][1]=1;a[0][3]=1;
//        a[1][0]=1;a[1][2]=1;a[1][4]=1;
//        a[2][1]=1;a[2][3]=1;a[2][4]=1;
//        a[3][0]=1;a[3][2]=1;a[3][4]=1;
//        a[4][1]=1;a[4][2]=1;a[4][3]=1;        
    }

    public void outHalmilton() {
        for (int j = 0; j < n + 1; j++) {
            System.out.print(v[X[j]] + " ");
        }
        System.out.println();
        countHamilton++;
    }

    public void hamilton(int k, boolean not[]) {
        for (int j = 0; j < n; j++) {
            if (a[X[k - 1]][j] == 1 && not[j] == true) {
                X[k] = j;
                if (k < n - 1) {
                    not[j] = false;
                    hamilton(k + 1, not);
                    not[j] = true;
                } else if (a[j][X[0]] == 1) {
                    outHalmilton();
                }
            }
        }
    }

    public void displayHamiltonCycle() {
        boolean not[] = new boolean[n];
        X = new int[n + 1];
        System.out.println("Hamilton cycles are in Graph:");
        for (int i = 0; i < n; i++) {
            not[i] = true;
        }
        not[0] = false;
        X[0] = 0;
        countHamilton = 0;
        hamilton(1, not);
        System.out.println("Number of Hamilton cycle:" + countHamilton);
    }

    void fvisit(int i, RandomAccessFile f) throws Exception {
        f.writeBytes(" " + v[i]);
    }

    void breadth(boolean[] en, int i, RandomAccessFile f) throws Exception {
        Queue q = new Queue();
        int r, j;
        q.enqueue(i);
        en[i] = true;
        while (!q.isEmpty()) {
            r = q.dequeue();
            fvisit(r, f);
            for (j = 0; j < n; j++) {
                if (!en[j] && a[r][j] > 0) {
                    q.enqueue(j);
                    en[j] = true;
                }
            }
        }
    }

    void breadth(int k, RandomAccessFile f) throws Exception {
        boolean[] en = new boolean[n];
        int i;
        for (i = 0; i < n; i++) {
            en[i] = false;
        }
        breadth(en, k, f);
        for (i = 0; i < n; i++) {
            if (!en[i]) {
                breadth(en, i, f);
            }
        }
    }

    void depth(boolean[] visited, int k, RandomAccessFile f) throws Exception {
        fvisit(k, f);
        visited[k] = true;
        for (int i = 0; i < n; i++) {
            if (!visited[i] && a[k][i] > 0) {
                depth(visited, i, f);
            }
        }
    }

    void depth(int k, RandomAccessFile f) throws Exception {
        boolean[] visited = new boolean[20];
        int i;
        for (i = 0; i < n; i++) {
            visited[i] = false;
        }
        depth(visited, k, f);
        for (i = 0; i < n; i++) {
            if (!visited[i]) {
                depth(visited, i, f);
            }
        }
    }
}
