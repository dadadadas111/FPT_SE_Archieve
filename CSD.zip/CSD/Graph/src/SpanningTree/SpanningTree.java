package SpanningTree;

public class SpanningTree {

    final int MAX = 1000000;
    int m;
    int n;
    Edge listOfEdge[];
    int C[][];

    SpanningTree(int numberOfVertices, int numberOfEdge) {
        n = numberOfVertices;
        m = numberOfEdge;
        listOfEdge = new Edge[m];
        C = new int[n][n];
    }

    public void inputKruskal() {
        listOfEdge[0] = new Edge(0, 1, 1);
        listOfEdge[1] = new Edge(0, 2, 9);
        listOfEdge[2] = new Edge(0, 3, 2);
        listOfEdge[3] = new Edge(1, 2, 30);
        listOfEdge[4] = new Edge(1, 3, 4);
        listOfEdge[5] = new Edge(1, 4, 1);
        listOfEdge[6] = new Edge(2, 3, 5);
        listOfEdge[7] = new Edge(2, 5, 20);
        listOfEdge[8] = new Edge(3, 4, 6);
        listOfEdge[9] = new Edge(3, 5, 7);
        listOfEdge[10] = new Edge(4, 5, 80);
    }

    public void kruskal() {
        int sum;
        int set[] = new int[n];
        int count, id;
        Edge e;
        for (int i = 0; i < m - 1; i++) {
            for (int j = i + 1; j < m; j++) {
                if (listOfEdge[i].weight > listOfEdge[j].weight) {
                    e = listOfEdge[i];
                    listOfEdge[i] = listOfEdge[j];
                    listOfEdge[j] = e;
                }
            }
        }
        for (int i = 0; i < n; i++) {
            set[i] = 0;
        }
        id = 1;
        int i = 0;
        count = 1;
        set[listOfEdge[0].head] = id;
        set[listOfEdge[0].tail] = id; //Create set A containing a set of vertices
        output(listOfEdge[0].head, listOfEdge[0].tail, listOfEdge[0].weight);
        sum = listOfEdge[0].weight;
        while (count < n - 1) {
            i = i + 1;
            if (set[listOfEdge[i].head] == 0 && set[listOfEdge[i].tail] == 0) {
                //The two vertices do not belong to set A
                id = id + 1;
                set[listOfEdge[i].head] = id;
                set[listOfEdge[i].tail] = id; //Tao tap dinh moi
                output(listOfEdge[i].head, listOfEdge[i].head, listOfEdge[i].weight);
                sum = sum + listOfEdge[i].weight;
                count = count + 1;
            }
            if (set[listOfEdge[i].head] != 0 && set[listOfEdge[i].tail] == 0) {
                //The head belongs to A, tail does not belong to A
                set[listOfEdge[i].tail] = set[listOfEdge[i].head];// push tail into A
                output(listOfEdge[i].head, listOfEdge[i].tail, listOfEdge[i].weight);
                sum = sum + listOfEdge[i].weight;
                count = count + 1;
            }
            if (set[listOfEdge[i].head] == 0 && set[listOfEdge[i].tail] != 0) {
                //head does not belong to A, tail belong to A
                set[listOfEdge[i].head] = set[listOfEdge[i].tail]; // push head in to A
                output(listOfEdge[i].head, listOfEdge[i].tail, listOfEdge[i].weight);
                sum = sum + listOfEdge[i].weight;
                count = count + 1;
            }
            if ((set[listOfEdge[i].head] != 0 && set[listOfEdge[i].tail] != 0) && set[listOfEdge[i].head] != set[listOfEdge[i].tail]) {
                // head belong to A1, tail belong to A2
                for (int k = 0; k < n; k++) {
                    if (set[k] == set[listOfEdge[i].tail]) {
                        set[k] = set[listOfEdge[i].head]; // A2 merges into A1
                    }
                }
                output(listOfEdge[i].head, listOfEdge[i].tail, listOfEdge[i].weight);
                sum = sum + listOfEdge[i].weight;
                count = count + 1;
            }
        }
        System.out.println("Weighted total: " + sum);
    }

    void output(int head, int tail, int w) {
        System.out.println("(" + head + "," + tail + "):" + w);
    }

    public void iputPrim() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                C[i][j] = MAX;
            }
        }
        for (int i = 0; i < n; i++) {
            C[i][i] = 0;
        }
        C[0][1] = 1;
        C[0][2] = 9;
        C[0][3] = 2;
        C[1][0] = 1;
        C[1][2] = 30;
        C[1][3] = 4;
        C[1][4] = 1;
        C[2][0] = 9;
        C[2][1] = 30;
        C[2][3] = 5;
        C[2][5] = 20;
        C[3][0] = 2;
        C[3][1] = 4;
        C[3][2] = 5;
        C[3][4] = 6;
        C[3][5] = 7;
        C[4][1] = 1;
        C[4][3] = 6;
        C[4][5] = 80;
        C[5][2] = 20;
        C[5][3] = 7;
        C[5][4] = 80;
    }

    public void prim(int start) {
        int stop, minVertice, min;
        int d[] = new int[n];
        int near[] = new int[n];
        int set[] = new int[n];
        int sum;
        for (int v = 0; v < n; v++) {
            set[v] = 0;
        }
        set[start] = 1;
        d[start] = 0;
        near[start] = start;
        for (int v = 0; v < n; v++) {
            d[v] = C[start][v];
            near[v] = start;
        }
        stop = 0;
        sum = 0;
        minVertice = start;
        while (stop < n - 1) {
            min = MAX;
            for (int v = 0; v < n; v++) {
                if (set[v] == 0 && min > d[v]) {
                    min = d[v];
                    minVertice = v;
                }
            }
            set[minVertice] = 1;
            System.out.println("(" + minVertice + "," + near[minVertice] + "):" + C[minVertice][near[minVertice]]);
            stop = stop + 1;
            sum = sum + C[minVertice][near[minVertice]];
            for (int v = 0; v < n; v++) {
                if (set[v] == 0) {
                    if (d[v] > C[minVertice][v]) {
                        d[v] = C[minVertice][v];
                        near[v] = minVertice;
                    }
                }
            }
        }
        System.out.println("Weighted total: " + sum);
    }
}
