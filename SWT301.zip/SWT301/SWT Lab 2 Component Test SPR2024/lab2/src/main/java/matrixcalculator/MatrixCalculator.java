

package matrixcalculator;

public class MatrixCalculator {
    public int[][] addMatrices(int[][] matrix1, int[][] matrix2) {
        // check condition
        if (matrix1.length != matrix2.length || matrix1[0].length != matrix2[0].length) {
            throw new IllegalArgumentException("Matrices must have the same dimensions");
        }
        int rows = matrix1.length;
        int columns = matrix1[0].length;
        int[][] sum = new int[rows][columns];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                sum[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }

        return sum;
    }

    public int[][] subtractMatrices(int[][] matrix1, int[][] matrix2) {
        if (matrix1.length != matrix2.length || matrix1[0].length != matrix2[0].length) {
            throw new IllegalArgumentException("Matrices must have the same dimensions");
        }
        int rows = matrix1.length;
        int columns = matrix1[0].length;
        int[][] difference = new int[rows][columns];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                difference[i][j] = matrix1[i][j] - matrix2[i][j];
            }
        }

        return difference;
    }

    public int[][] multiplyMatrices(int[][] matrix1, int[][] matrix2) {
        // check condition
        if (matrix1[0].length != matrix2.length) {
            throw new IllegalArgumentException("Invalid matrix dimensions for multiplication");
        }
        int rows1 = matrix1.length;
        int columns1 = matrix1[0].length;
        int columns2 = matrix2[0].length;
        int[][] product = new int[rows1][columns2];

        for (int i = 0; i < rows1; i++) {
            for (int j = 0; j < columns2; j++) {
                for (int k = 0; k < columns1; k++) {
                    product[i][j] += matrix1[i][k] * matrix2[k][j];
                }
            }
        }

        return product;
    }

    public int[][] transposeMatrix(int[][] matrix) {
        int rows = matrix.length;
        int columns = matrix[0].length;
        if (rows != columns) {
            throw new IllegalArgumentException("Matrix must be square for transposition");
        }
        int[][] transpose = new int[columns][rows];

        for (int i = 0; i < columns; i++) {
            for (int j = 0; j < rows; j++) {
                transpose[i][j] = matrix[j][i];
            }
        }

        return transpose;
    }

    public int[][] scalarMultiplication(int[][] matrix, int scalar) {
        int rows = matrix.length;
        int columns = matrix[0].length;
        int[][] result = new int[rows][columns];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                result[i][j] = matrix[i][j] * scalar;
            }
        }
        return result;
    }

    public int[][] powerOfMatrix(int[][] matrix, int power) {
        if (matrix.length != matrix[0].length) {
            throw new IllegalArgumentException("Matrix must be square for exponentiation");
        }
        int[][] result = matrix;
        for (int i = 1; i < power; i++) {
            result = multiplyMatrices(result, matrix);
        }
        return result;
    }

    public int determinantOfMatrix(int[][] matrix) {
        if (matrix.length != matrix[0].length) {
            throw new IllegalArgumentException("Matrix must be square for determinant calculation");
        }
        int n = matrix.length;
        if (n == 1) {
            return matrix[0][0];
        }
        int determinant = 0;
        int sign = 1;
        for (int i = 0; i < n; i++) {
            int[][] subMatrix = new int[n - 1][n - 1];
            for (int j = 1; j < n; j++) {
                int subMatrixColumn = 0;
                for (int k = 0; k < n; k++) {
                    if (k != i) {
                        subMatrix[j - 1][subMatrixColumn] = matrix[j][k];
                        subMatrixColumn++;
                    }
                }
            }
            determinant += sign * matrix[0][i] * determinantOfMatrix(subMatrix);
            sign *= -1;
        }
        return determinant;
    }

    public boolean isSymmetric(int[][] matrix) {
        int rows = matrix.length;
        int columns = matrix[0].length;
        if (rows != columns) {
            throw new IllegalArgumentException("Matrix must be square for symmetry check");
        }
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < i; j++) {
                if (matrix[i][j] != matrix[j][i]) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean isDiagonal(int[][] matrix) {
        int rows = matrix.length;
        int columns = matrix[0].length;
        if (rows != columns) {
            throw new IllegalArgumentException("Matrix must be square for diagonal check");
        }
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (i != j && matrix[i][j] != 0) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean isIdentity(int[][] matrix) {
        int rows = matrix.length;
        int columns = matrix[0].length;
        if (rows != columns) {
            throw new IllegalArgumentException("Matrix must be square for identity check");
        }
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (i == j && matrix[i][j] != 1) {
                    return false;
                } else if (i != j && matrix[i][j] != 0) {
                    return false;
                }
            }
        }
        return true;
    }
}
