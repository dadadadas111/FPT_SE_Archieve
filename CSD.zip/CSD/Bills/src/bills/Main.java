/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bills;

/**
 *
 * @author asus
 */
public class Main {

    public static void main(String[] args) {
        
        run();
                  
    }

    public static void run() {

        // Step 1. User enter bills information
        int[] bills = enterBills();

        // Step 2. User enter wallet value
        int wallet = enterWallet();

        // Step 3. Display result
        displayResult(bills, wallet);
        
    }

    private static int[] enterBills() {
        System.out.println("======= Shopping program ==========");
        int size = Input.enterPositiveInt("input number of bill:");

        int[] bills = new int[size];

        // loop to all elements in bills
        for (int i = 0; i < bills.length; i++) {
            bills[i] = Input.enterPositiveInt("input value of bill " + (i+1) + ":");

        }

        return bills;
    }

    private static int enterWallet() {
        return Input.enterInt("input value of wallet:", 0, "wallet cannot be negative. Try again");
    }

    private static void displayResult(int[] bills, int wallet) {
        int total = calTotal(bills);

        System.out.println("this is total of bill:" + total);

        // check if wallet can pay total
        if (payMoney(total, wallet)) {
            System.out.println("You can buy it.");
        } else {
            System.out.println("you can't buy it.");
        }

    }

    private static int calTotal(int[] bills) {
        int total = 0;
        // loop to all elements in bills
        for (int bill : bills) {
            total += bill;
        }
        
        return total;
    }

    private static boolean payMoney(int total, int wallet) {
        return wallet >= total;
    }

}
