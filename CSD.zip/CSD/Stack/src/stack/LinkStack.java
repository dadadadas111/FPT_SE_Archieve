/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stack;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author asus
 */
public class LinkStack {
    Node top;

    public LinkStack() {
        top = null;
    }
    
    public void clear(){
        top = null;
    }
    public boolean isEmpty(){
        return top == null;
    }
    public void push(Object x){
        top = new Node(x, top);
        // p = new Node (x, top)
        // top = p
    }
    public Object peek() throws Exception{
        if (isEmpty()) {
            throw new Exception();
        }
        return top.info;
    }
    public Object pop(){
        if (isEmpty()){
            return null;
        }
        Object x = top.info;
        top = top.next;
        return x;
    }
    public void toBinary(int x){
        clear();
        do {            
            push(x % 2);
            x /= 2;
        } while (x != 0);
        Node p = top;
        while (p != null) {
            System.out.print(p.info);
            p = p.next;
        }
    }
    public boolean checkSym(String s){
        char[] arr = s.toCharArray();
        for (int i = 0; i < arr.length; i++) {
            push(arr[i]);
        }
        for (int i = 0; i < arr.length; i++) {
            try {
                if (((char)pop()) != arr[i]) return false;
            } catch (Exception ex) {
                Logger.getLogger(LinkStack.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        return true;
    }
    
    public Object removeK(int k){
        LinkStack st = new LinkStack();
        int i = 1;
        while ( i  != k){
            st.push(( pop());
            i++;
        }
    }
}
