/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singlylinkedlist;

/**
 *
 * @author asus
 */
public class SingleLinkedList {

    Node head, tail;

    public SingleLinkedList() {
        head = tail = null;
    }

    public boolean isEmpty() {
        return (head == null);
    }

    public void clear() {
        head = tail = null;
    }

//    public void addLast(int x) {
//        Node p = new Node(x, null);
//        if (isEmpty()) {
//            head = tail = p;
//        } else {
//            tail.next = p;
//            tail = p;
//        }
//    }
    public void addLast(int x) {
        Node p = new Node(x);
        Node tmp = head;
        if (isEmpty()) {
            head = p;
        } else {
            while (tmp.next != null) {
                tmp = tmp.next;
            }
            tmp.next = p;
        }
    }

    public void addFirst(int x) {
        Node p = new Node(x);
        if (isEmpty()) {
            head = tail = p;
        } else {
            p.next = head;
            head = p;
        }

    }

    public void show() {
        Node p = head;
        while (p != null) {
            System.out.print(" " + p.info);
            p = p.next;
        }
        System.out.println();
    }

    public Node search(int x) {
        Node p = head;
        while (p != null) {
            if (p.info == x) {
                System.out.println("Found");
                return p;
            }
            p = p.next;
        }
        System.out.println("Not Found");
        return null;
    }

    public void dele(int x) {
        Node p = head;
        if (p.info == x) {
            head = p.next;
            System.out.println("Finished");
            return;
        }
        while (p.next != null) {
            if (p.next.info == x) {
                p.next = p.next.next;
                System.out.println("Finished");
                return;
            }
            p = p.next;
        }
        System.out.println("Not Found");
    }

    public int getSize() {
        int size = 0;
        Node p = head;
        while (p != null) {
            size++;
            p = p.next;
        }
        return size;
    }

    // slot 1
    public Node removeFromLast(int index) {

        // assume index is always a valid
        // assume index is counted from 0 to size - 1
        int pos = getSize() - index - 1;
        if (pos == 0) {
            head = head.next;
            return head;
        }

        Node p = head;

        for (int i = 0; i < pos - 1; i++) {
            p = p.next;
        }
        p.next = p.next.next;
        return head;
    }

    public Node getMiddleNode() {
        int pos = getSize() / 2;
        Node p = head;
        for (int i = 0; i < pos; i++) {
            p = p.next;
        }
        return p;
    }

    public boolean isPalindrome() {
        
        // 1 2 3 4 5 4 3 2 1 
        if (isEmpty()) {
            return false;
        }
        SingleLinkedList reverseList = new SingleLinkedList();
        Node p = head;

        for (int i = 0; i < getSize() / 2; i++) {
            reverseList.addFirst(p.info);
            p = p.next;
        }
        // 4 3 2 1 
        p = getMiddleNode();
        if (getSize() % 2 == 1) {
            p = p.next;
        }
        Node p2 = reverseList.head;
        while (p != null) {
            if (p.info != p2.info) {
                return false;
            }
            p = p.next;
            p2 = p2.next;
        }
        return true;

    }

    public void removeDuplicate() {
        // since the linked list is sorted, the duplicates will be adjacent
        Node p = head;
        while (p != null && p.next != null) {
            if (p.info == p.next.info) {
                p.next = p.next.next;
            }
            p = p.next;
        }
    }

    public void removeFirst() {
        if (isEmpty()) {
            System.out.println("Empty list! Delete failed!");
            return;
        }
        if (getSize() == 1) {
            head = tail = null;
            return;
        }
        head = head.next;
    }

    public void removeLast() {
        if (isEmpty()) {
            System.out.println("Empty list! Delete failed!");
            return;
        }
        if (getSize() == 1) {
            head = tail = null;
            return;
        }
        Node p = head;
        while (p.next != tail) {
            p = p.next;
        }
        p.next = null;
        tail = p;
    }

    public void insert(Node p, int x) {
        if (p == null) {
            System.out.println("failed");
            return;
        }
        if (p == head){
            p = new Node(x, head);
            return;
        }
        Node r = head;
        while (r.next != p) r = r.next;
        r.next = new Node(x, p);
    }
    
    public int find(int x){
        if (isEmpty()) return 0;
        int pos = 1;
        Node p = head;
        while (p != null && p.info!= x){
            p=p.next;
            pos++;
        }
        return (p==null) ? 0: pos;
    }
    
    public void removeNext(Node p){
        if (p == null || p.next == null) {
            System.out.println("Failed");
        }
        else {
            p.next = p.next.next;
        }
    }
    
    public void removePrev(Node p){
        Node r = head;
        if (r.next == p){
            head = p;
        }
        else{
            while (r.next.next != p){
                r = r.next;
            }
            r.next = p;
        }
    }
    public void findAll(int x){
        Node p = head;
        int pos = 1;
        while (p != null ){
            if (p.info == x) {
                System.out.print(" " + pos);
            }
            pos++;
            p = p.next;
        }
        System.out.println("");
    }
}
