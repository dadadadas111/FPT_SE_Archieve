-- trigger to calculate total_amount for Orders when OrderDetails inserted/deleted
ALTER TRIGGER calculate_total_amount
ON OrderDetails
AFTER INSERT, DELETE
AS
BEGIN
	
	UPDATE Orders
	SET total_amount = dbo.total_amount( Order_ID)
	WHERE Order_ID IN (SELECT DISTINCT (Order_ID) FROM inserted UNION SELECT DISTINCT (Order_ID)  FROM deleted)


END

-- test

--1. delete before test
delete OrderDetails
where order_detail_id = 11

--2. start test
select * from Orders

INSERT INTO OrderDetails
VALUES (11, 5, 11);

select * from Orders



-- trigger to prevent order_date > show start_time
CREATE TRIGGER check_valid_order_date
ON OrderDetails
AFTER INSERT 

AS
BEGIN
	
	IF EXISTS (
		SELECT 1
		FROM
			inserted i JOIN
			Orders O ON O.Order_id = i.Order_id JOIN  
			Tickets T ON i.ticket_id = T.ticket_id JOIN
			Showtimes S ON T.showtime_id = S.showtime_id
		WHERE
			order_date > start_time		
	
	)
	BEGIN
		print 'order_date > show start_time'
		rollback transaction
	END
	
END

-- test

-- 1. delete first

delete orderdetails
where order_detail_id = 100

delete tickets
where ticket_id = 100


-- 2. start test
INSERT INTO Tickets (ticket_id, showtime_id, seat_id, price)
VALUES (100, 1, 1, 20.00)

INSERT INTO OrderDetails(order_detail_id, order_id, ticket_id)
VALUES(100, 10, 100)

