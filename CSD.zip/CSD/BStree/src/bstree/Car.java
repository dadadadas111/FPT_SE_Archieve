/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bstree;

/**
 *
 * @author asus
 */
public class Car {
    String owner;
    int price;

    public Car(String owner, int price) {
        this.owner = owner;
        this.price = price;
    }

    @Override
    public String toString() {
        return '{' + owner +  + price + '}';
    }
    
}
