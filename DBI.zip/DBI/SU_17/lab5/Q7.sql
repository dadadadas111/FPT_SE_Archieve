create proc SP_AddEvenNumberToDummy 
@Threshold int
AS
	BEGIN
		declare @i int = 0
		while @Threshold >= @i 
			BEGIN
				INSERT INTO DummyTable
				Values (@i)
				SET @i = @i + 2
			END
		
	END

