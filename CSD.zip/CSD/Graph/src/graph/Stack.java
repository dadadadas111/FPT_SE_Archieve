package graph;
public class Stack {
    Node top;
    Stack(){
        top=null;
    }
    public boolean isEmpty(){
        if(top==null) return true;
        else return false;
    }
    public void push(Object x){
        Node p=new Node(x,top);
        top=p;
    }
    public Object pop(){
        if(isEmpty()) return null;
        Object x=top.infor;
        top=top.next;
        return x;
    }
    public Object peek(){
        if(isEmpty()) return null;
        else return top.infor;
    }
    public int len(){
        if(isEmpty()) return 0;
        Node p= new Node();
        p=top;
        int i=0;
        while(p!=null){
            i++;
            p=p.next;
        }
        return i;
    }
    public int search(Object x){
        if(isEmpty()) return -1;
        Node p=top;
        int i=0;
        while(p!=null && p.infor!=x){
            i++;
            p=p.next;
        }
        if(p==null) return -1;
        else return i;

    }

}
