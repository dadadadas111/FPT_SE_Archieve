with product_location_count as (

SELECT    Product.ProductID, Product.Name AS ProductName,
	COUNT(Location.LocationID) as NumberOfLocations,
	ProductModel.ModelID
FROM         ProductModel LEFT JOIN
                      Product ON ProductModel.ModelID = Product.ModelID LEFT OUTER JOIN
                      ProductInventory ON Product.ProductID = ProductInventory.ProductID LEFT OUTER JOIN
                      Location ON ProductInventory.LocationID = Location.LocationID
GROUP BY 
	Product.ProductID,
	Product.Name,
	ProductModel.ModelID
)

select
	pm.ModelID,
	pm.Name as ModelName,
	ProductID,
	ProductName,
	NumberOfLocations
from product_location_count r1 right join ProductModel pm on r1.ModelID = pm.ModelID 
where  pm.Name like 'HL Mountain%'
and NumberOfLocations = (select max(NumberOfLocations) from product_location_count where ModelID = pm.ModelID)
order by
 ModelID
