use Lab3_2;

CREATE TABLE Primary_skill(
	id char(10) primary key,
	_name varchar(10),
	hourly_billing_rate float
)

CREATE TABLE Employee(
	id char(10) primary key,
	_name varchar(10),
	Skill_id char(10) references Primary_skill(id)
)

CREATE TABLE Project (
	id char(10) primary key,
	_name varchar (10)
)
CREATE TABLE work_on(
	Project_id char(10) references Project(id),
	Employee_id char(10) references Employee(id),
	hours_worked float
)

CREATE TABLE need(
	Project_id char(10) references Project(id),
	Skill_id char(10) references Primary_skill(id)
)
