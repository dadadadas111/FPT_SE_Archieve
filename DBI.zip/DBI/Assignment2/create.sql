CREATE TABLE Cinemas (
  cinema_id INT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  address VARCHAR(255) NOT NULL,
  number_of_rooms INT NOT NULL
);

CREATE TABLE Rooms (
  room_id INT PRIMARY KEY,
  cinema_id INT NOT NULL,
  FOREIGN KEY (cinema_id) REFERENCES Cinemas(cinema_id),
  name VARCHAR(255) NOT NULL,
  capacity INT NOT NULL
);

CREATE TABLE Seats (
  seat_id INT PRIMARY KEY,
  room_id INT NOT NULL,
  FOREIGN KEY (room_id) REFERENCES Rooms(room_id),
  row_number INT NOT NULL,
  seat_number INT NOT NULL
);

CREATE TABLE Movies (
  movie_id INT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  genre VARCHAR(255) NOT NULL,
  duration INT NOT NULL,
  age_limit INT NOT NULL
);

CREATE TABLE Showtimes (
  showtime_id INT PRIMARY KEY,
  movie_id INT NOT NULL,
  FOREIGN KEY (movie_id) REFERENCES Movies(movie_id),
  room_id INT NOT NULL,
  FOREIGN KEY (room_id) REFERENCES Rooms(room_id),
  start_time DATETIME NOT NULL,
  end_time DATETIME NOT NULL
);

CREATE TABLE Tickets (
  ticket_id INT PRIMARY KEY,
  showtime_id INT NOT NULL,
  FOREIGN KEY (showtime_id) REFERENCES Showtimes(showtime_id),
  price DECIMAL(10,2) NOT NULL
);




CREATE TABLE Customers (
  customer_id INT PRIMARY KEY,
  first_name VARCHAR(255) NOT NULL,
  last_name VARCHAR(255) NOT NULL,
  date_of_birth DATE NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone_number VARCHAR(255) NOT NULL
);


CREATE TABLE Orders (
  order_id INT PRIMARY KEY,
  customer_id INT NOT NULL,
  FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
  order_date DATE NOT NULL,
  order_type VARCHAR(255) NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL
);


CREATE TABLE OrderDetails (
  order_detail_id INT PRIMARY KEY,
  order_id INT NOT NULL,
  FOREIGN KEY (order_id) REFERENCES Orders(order_id),
  ticket_id INT NOT NULL,
  FOREIGN KEY (ticket_id) REFERENCES Tickets(ticket_id)
);
