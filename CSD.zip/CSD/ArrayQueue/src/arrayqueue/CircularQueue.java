/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayqueue;

/**
 *
 * @author asus
 */
public class CircularQueue {

    Node head;

    CircularQueue() {
        head = null;
    }

    public boolean isEmpty() {
        if (head == null) {
            return true;
        } else {
            return false;
        }
    }

    public Node getPrev(Node r) {
        if (isEmpty()) {
            return null;
        }
        if (r == head && head.next == head) {
            return head;
        }
        Node p = head;
        while (p.next != r) {
            p = p.next;
        }
        return p;
    }

    public void enqueue(Object x) {
        Node p = new Node(x);
        if (isEmpty()) {
            head = p;
            head.next = head;
            return;
        }
        Node last = getPrev(head);
        p.next = head;
        last.next = p;
    }

    public Object dequeue() {
        if (isEmpty()) {
            return null;
        }
        Object x = head.info;
        if (head == head.next) {
            head = null;
        } else {
            Node last = getPrev(head);
            head = head.next;
            last.next = head;
        }

        return x;
    }

    public Object front() {
        if (isEmpty()) {
            return null;
        }
        Object x = head.info;
        return x;
    }

    public int length() {
        if (isEmpty()) {
            return 0;
        }
        Node p = head;
        int count = 1;
        while (p.next != head) {
            p = p.next;
            count++;
        }
        return count;
    }

    public void input(int n) {
        for (int i = 0; i < n; i++) {
            enqueue(i);
        }
    }

    public void output() {
        while (!isEmpty()) {
            System.out.println(dequeue());
        }
    }
}
