/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dictionary;

import java.util.HashMap;
import java.io.*;
import java.util.Map;

/**
 *
 * @author asus
 */
public class Manager {

    public static HashMap<String, String> loadData() {
        HashMap<String, String> dictionary = new HashMap();

        File f = new File("dictionary.txt");

        try {
            // if there is no dictionary file
            if (!f.exists()) {
                f.createNewFile();
            } else {
                BufferedReader bf = new BufferedReader(new FileReader(f));
                String line;

                // loop if there is still line to read
                while ((line = bf.readLine()) != null) {

                    // split strings by comma
                    String[] s = line.split(",");

                    // Check if s dont have 2 elements
                    if (s.length != 2) {
                        continue;
                    }
                    dictionary.put(s[0], s[1]);

                }
                bf.close();
            }
        } catch (Exception e) {

        }
        return dictionary;
    }

    public static void displayMenu() {
        System.out.println("======== Dictionary program ========\n"
                + "1.Add Word\n"
                + "2.Delete Word\n"
                + "3.Translate\n"
                + "4.Exit");
    }

    public static void performFunction(int choice, HashMap dictionary) {

        // check value of choice
        switch (choice) {
            case 1:
                addWord(dictionary);
                break;
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
        }
    }

    private static void addWord(HashMap dictionary) {
        System.out.println("------------- Add -------------");
        String en = DataValidation.enterString("Enter English: ");
        // check if english word already exists
        if (dictionary.containsKey(en.toUpperCase())){
            
        }
        String vi = DataValidation.enterString("Enter Vietnamese: ");
        updateData(dictionary);
        System.out.println("Successful");
    }


    private static void updateData(HashMap dictionary) {
        File f = new File("dictionary.txt");

        try {
            f.delete();
            f.createNewFile();
            BufferedWriter bw = new BufferedWriter (new FileWriter(f));
            // loop to access every entry in dictionary
            for (Object entry : dictionary.entrySet()) {
                String en = ((Map.Entry<String,String>) entry ).getKey();
                String vi = ((Map.Entry<String,String>) entry ).getValue();
                bw.write(en + "," + vi);
                bw.newLine();
                
            }

        } catch (Exception e) {

        }
    }

}
