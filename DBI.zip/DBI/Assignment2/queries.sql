--A. inner join

-- online order customers older than 18 ordered in 11/2023
SELECT 
	distinct c.*, 
	o.order_type 
FROM
	Customers c 
	JOIN Orders o ON c.Customer_id = o.customer_id
WHERE
	order_type = 'Online' 
	AND DATEDIFF(year, date_of_birth, order_date) > 18 
	AND year(order_date) = 2023 


-- tickets with showtime start before 20:00 on 11/10/2023
SELECT t.ticket_id, s.showtime_id, m.title, s.start_time, s.end_time, t.seat_id, t.price
FROM Tickets t
INNER JOIN Showtimes s ON t.showtime_id = s.showtime_id
INNER JOIN Movies m ON s.movie_id = m.movie_id
WHERE start_time between '2023-11-10 00:00:00' and '2023-11-10 20:00:00' ;


--B. outer join

-- Find all customers who have at least one order.
SELECT c.customer_id, c.first_name, c.last_name, c.date_of_birth, c.email, c.phone_number
FROM Customers c
LEFT JOIN Orders o ON c.customer_id = o.customer_id
WHERE o.order_id IS NOT NULL;


-- Find all showtimes that do not have any tickets associated with them.
SELECT s.showtime_id, s.start_time, s.end_time
FROM Showtimes s
LEFT JOIN Tickets t ON s.showtime_id = t.showtime_id
WHERE t.ticket_id IS NULL;


-- C. subquery in where

-- Find all orders that have a total amount greater than the average total amount of all orders.
SELECT o.order_id, c.first_name, c.last_name, o.order_date, o.order_type, o.total_amount
FROM Orders o
INNER JOIN Customers c ON o.customer_id = c.customer_id
WHERE o.total_amount >= (SELECT AVG(total_amount) FROM Orders);

-- Find all tickets that are associated with seats that has id = 1.
SELECT t.ticket_id, s.showtime_id, m.title, s.start_time, s.end_time, t.seat_id, t.price
FROM Tickets t
INNER JOIN Showtimes s ON t.showtime_id = s.showtime_id
INNER JOIN Movies m ON s.movie_id = m.movie_id
INNER JOIN Seats st ON t.seat_id = st.seat_id
WHERE st.seat_id = 1;


-- D. subquery in from
-- 1. Get the total number of seats in each room
SELECT R.name, COUNT(*) as total_seats
FROM Rooms R, (SELECT * FROM Seats) S
WHERE R.room_id = S.room_id
GROUP BY R.name;

-- 2. Get the total number of seats sold for each showtime
SELECT S.showtime_id, COUNT(*) as total_seats
FROM Showtimes S LEFT JOIN (SELECT T1.* FROM Tickets T1 INNER JOIN OrderDetails OD ON T1.ticket_id = OD.ticket_id) T
ON S.showtime_id = T.showtime_id
GROUP BY S.showtime_id;

-- e. Query using group by and aggregate functions.
-- 1. Get the total number of rooms in each cinema
SELECT cinema_id, COUNT(*) as total_rooms
FROM Rooms
GROUP BY cinema_id;

-- 2. Get the total number of tickets sold for each movie
SELECT M.movie_id, M.title, COUNT(*) as total_tickets
FROM Movies M LEFT JOIN  Showtimes S
ON M.movie_id = S.movie_id LEFT JOIN Tickets T ON S.showtime_id = T.showtime_id
GROUP BY M.movie_id, M.title;



