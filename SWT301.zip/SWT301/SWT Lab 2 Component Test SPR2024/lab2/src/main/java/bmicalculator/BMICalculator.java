package bmicalculator;

import java.util.Scanner;

public class BMICalculator {

    private double weight;
    private double height;

    public BMICalculator(double weight, double height) {
        // check validation
        if (weight <= 0 || height <= 0) {
            throw new IllegalArgumentException("Weight and height must be greater than 0");
        }
        this.weight = weight;
        this.height = height;
    }

    public double calculateBMI() {
        double bmi = weight / (height * height);
        return bmi;
    }

    public String getBMICategory() {
        double bmi = calculateBMI();
        if (bmi < 18.5) {
            return "Underweight";
        } else if (bmi >= 18.5 && bmi < 25) {
            return "Normal";
        } else if (bmi >= 25 && bmi < 30) {
            return "Overweight";
        } else {
            return "Obese";
        }
    }

    public double calculateIdealWeight() {
        double idealWeight = 22 * (height * height);
        return idealWeight;
    }

    public double calculateWeightDifference() {
        double idealWeight = calculateIdealWeight();
        double weightDifference = idealWeight - weight;
        return weightDifference;
    }

    public double convertWeightToPounds() {
        double weightInPounds = weight * 2.20462;
        return weightInPounds;
    }

    public double convertHeightToInches() {
        double heightInInches = height * 39.3701;
        return heightInInches;
    }

    public double convertHeightToFeet() {
        double heightInFeet = height * 3.28084;
        return heightInFeet;
    }

    public void showMenu() {
        System.out.println("BMI Calculator Menu");
        System.out.println("Enter your choice:");
        System.out.println("1. Enter weight and height");
        System.out.println("2. Calculate BMI");
        System.out.println("3. Get BMI Category");
        System.out.println("4. Calculate Ideal Weight");
        System.out.println("5. Calculate Weight Difference");
        System.out.println("6. Convert Weight to Pounds");
        System.out.println("7. Convert Height to Inches");
        System.out.println("8. Convert Height to Feet");
        System.out.println("0. Exit");
    }

    public void processMenu(int choice) {
        switch (choice) {
            case 1:
                inputInfo();
                break;
            case 2:
                System.out.println("BMI: " + calculateBMI());
                break;
            case 3:
                System.out.println("BMI Category: " + getBMICategory());
                break;
            case 4:
                System.out.println("Ideal Weight: " + calculateIdealWeight());
                break;
            case 5:
                System.out.println("Weight Difference: " + calculateWeightDifference());
                break;
            case 6:
                System.out.println("Weight in Pounds: " + convertWeightToPounds());
                break;
            case 7:
                System.out.println("Height in Inches: " + convertHeightToInches());
                break;
            case 8:
                System.out.println("Height in Feet: " + convertHeightToFeet());
                break;
            case 0:
                System.out.println("Exiting...");
                break;
            default:
                System.out.println("Invalid choice");
        }
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public static void inputInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your weight in kg: ");
        double weight = scanner.nextDouble();
        System.out.print("Enter your height in meters: ");
        double height = scanner.nextDouble();
        BMICalculator bmiCalculator = new BMICalculator(weight, height);
        bmiCalculator.getChoice();
    }

    public static void getChoice() {
        Scanner scanner = new Scanner(System.in);
        BMICalculator bmiCalculator = new BMICalculator(0, 0);
        int choice;
        do {
            bmiCalculator.showMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            bmiCalculator.processMenu(choice);
        } while (choice != 0);
    }

}
