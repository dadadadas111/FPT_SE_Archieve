

package _validation;

public class Validation {
    
        public static boolean isPositive(double value) {
            return value > 0;
        }
    
        public static boolean isPositive(int value) {
            return value > 0;
        }
    
        public static boolean isPositive(long value) {
            return value > 0;
        }
    
        public static boolean isPositive(float value) {
            return value > 0;
        }
    
        public static boolean isPositive(short value) {
            return value > 0;
        }
    
        public static boolean isPositive(byte value) {
            return value > 0;
        }
    
        public static boolean isPositive(String value) {
            try {
                double number = Double.parseDouble(value);
                return number > 0;
            } catch (NumberFormatException e) {
                return false;
            }
        }
    
        public static boolean isNegative(double value) {
            return value < 0;
        }
    
        public static boolean isNegative(int value) {
            return value < 0;
        }
    
        public static boolean isNegative(long value) {
            return value < 0;
        }
    
        public static boolean isNegative(float value) {
            return value < 0;
        }
    
        public static boolean isNegative(short value) {
            return value < 0;
        }
    
        public static boolean isNegative(byte value) {
            return value < 0;
        }
    
        public static boolean isNegative(String value) {
            try {
                double number = Double.parseDouble(value);
                return number < 0;
            } catch (NumberFormatException e) {
                return false;
            }
        }
    
        public static boolean isNonNegative(double value) {
            return value >= 0;
        }
    
        public static boolean isNonNegative(int value) {
            return value >= 0;
        }
    
        public static boolean isNonNegative(long value) {
            return value >= 0;
        }
    
        public static boolean isNonNegative(float value) {
            return value >= 0;
        }
    
        public static boolean isNonNegative(short value) {
            return value >= 0;
        }
    
        public static boolean isNonNegative(byte value) {
            return value >= 0;
        }
    
        public static boolean isNonNegative(String value) {
            try {
                double number = Double.parseDouble(value);
                return number >= 0;
            } catch (NumberFormatException e) {
                return false;
            }
        }
    
        public static boolean isNonPositive(double value) {
            return value <= 0;
        }

        public static boolean isNonPositive(int value) {
            return value <= 0;
        }
        
        public static boolean isNonPositive(long value) {
            return value <= 0;
        }
        
        public static boolean isNonPositive(float value) {
            return value <= 0;
        }
        
        public static boolean isNonPositive(short value) {
            return value <= 0;
        }
        
        public static boolean isNonPositive(byte value) {
            return value <= 0;
        }
        
        public static boolean isNonPositive(String value) {
            try {
            double number = Double.parseDouble(value);
            return number <= 0;
            } catch (NumberFormatException e) {
            return false;
            }
        }
        
        public static boolean isEven(int value) {
            return value % 2 == 0;
        }
        
        public static boolean isEven(long value) {
            return value % 2 == 0;
        }
        
        public static boolean isEven(short value) {
            return value % 2 == 0;
        }
        
        public static boolean isEven(byte value) {
            return value % 2 == 0;
        }
        
        public static boolean isOdd(int value) {
            return value % 2 != 0;
        }
        
        public static boolean isOdd(long value) {
            return value % 2 != 0;
        }
        
        public static boolean isOdd(short value) {
            return value % 2 != 0;
        }
        
        public static boolean isOdd(byte value) {
            return value % 2 != 0;
        }
        
        public static boolean isPrime(int value) {
            if (value <= 1) {
            return false;
            }
            for (int i = 2; i <= Math.sqrt(value); i++) {
            if (value % i == 0) {
                return false;
            }
            }
            return true;
        }
        
        public static boolean isPrime(long value) {
            if (value <= 1) {
            return false;
            }
            for (long i = 2; i <= Math.sqrt(value); i++) {
            if (value % i == 0) {
                return false;
            }
            }
            return true;
        }
        
        public static boolean isPalindrome(String value) {
            String reversed = new StringBuilder(value).reverse().toString();
            return value.equals(reversed);
        }

        public static boolean isPalindrome(int value) {
            return isPalindrome(Integer.toString(value));
        }

        public static boolean isPalindrome(long value) {
            return isPalindrome(Long.toString(value));
        }

        public static boolean isPalindrome(short value) {
            return isPalindrome(Short.toString(value));
        }

        public static boolean isPalindrome(byte value) {
            return isPalindrome(Byte.toString(value));
        }

        public static boolean isPalindrome(double value) {
            return isPalindrome(Double.toString(value));
        }

        public static boolean isPalindrome(float value) {
            return isPalindrome(Float.toString(value));
        }

        public static boolean isPerfectSquare(int value) {
            double sqrt = Math.sqrt(value);
            return sqrt == Math.floor(sqrt);
        }

        public static boolean isPerfectSquare(long value) {
            double sqrt = Math.sqrt(value);
            return sqrt == Math.floor(sqrt);
        }

        public static boolean isPerfectSquare(double value) {
            double sqrt = Math.sqrt(value);
            return sqrt == Math.floor(sqrt);
        }

        public static boolean isPerfectSquare(float value) {
            double sqrt = Math.sqrt(value);
            return sqrt == Math.floor(sqrt);
        }

        public static boolean isPerfectSquare(short value) {
            double sqrt = Math.sqrt(value);
            return sqrt == Math.floor(sqrt);
        }

        public static boolean isPerfectSquare(byte value) {
            double sqrt = Math.sqrt(value);
            return sqrt == Math.floor(sqrt);
        }

        public static boolean isPerfectCube(int value) {
            double cbrt = Math.cbrt(value);
            return cbrt == Math.floor(cbrt);
        }

        public static boolean isPerfectCube(long value) {
            double cbrt = Math.cbrt(value);
            return cbrt == Math.floor(cbrt);
        }

        public static boolean isPerfectCube(double value) {
            double cbrt = Math.cbrt(value);
            return cbrt == Math.floor(cbrt);
        }

        public static boolean isPerfectCube(float value) {
            double cbrt = Math.cbrt(value);
            return cbrt == Math.floor(cbrt);
        }

        public static boolean isPerfectCube(short value) {
            double cbrt = Math.cbrt(value);
            return cbrt == Math.floor(cbrt);
        }

        public static boolean isPerfectCube(byte value) {
            double cbrt = Math.cbrt(value);
            return cbrt == Math.floor(cbrt);
        }

        public static boolean isPerfectPower(int value) {
            if (value <= 1) {
            return true;
            }
            for (int i = 2; i <= Math.sqrt(value); i++) {
            for (int j = 2; Math.pow(i, j) <= value; j++) {
                if (Math.pow(i, j) == value) {
                return true;
                }
            }
            }
            return false;
        }

        public static boolean isPerfectPower(long value) {
            if (value <= 1) {
            return true;
            }
            for (long i = 2; i <= Math.sqrt(value); i++) {
            for (long j = 2; Math.pow(i, j) <= value; j++) {
                if (Math.pow(i, j) == value) {
                return true;
                }
            }
            }
            return false;
        }

        public static boolean isPerfectPower(double value) {
            if (value <= 1) {
            return true;
            }
            for (double i = 2; i <= Math.sqrt(value); i++) {
            for (double j = 2; Math.pow(i, j) <= value; j++) {
                if (Math.pow(i, j) == value) {
                return true;
                }
            }
            }
            return false;
        }

        public static boolean isPerfectPower(float value) {
            if (value <= 1) {
            return true;
            }
            for (float i = 2; i <= Math.sqrt(value); i++) {
            for (float j = 2; Math.pow(i, j) <= value; j++) {
                if (Math.pow(i, j) == value) {
                return true;
                }
            }
            }
            return false;
        }

        public static boolean isPerfectPower(short value) {
            if (value <= 1) {
            return true;
            }
            for (short i = 2; i <= Math.sqrt(value); i++) {
            for (short j = 2; Math.pow(i, j) <= value; j++) {
                if (Math.pow(i, j) == value) {
                return true;
                }
            }
            }
            return false;
        }

        public static boolean isPerfectPower(byte value) {
            if (value <= 1) {
            return true;
            }
            for (byte i = 2; i <= Math.sqrt(value); i++) {
            for (byte j = 2; Math.pow(i, j) <= value; j++) {
                if (Math.pow(i, j) == value) {
                return true;
                }
            }
            }
            return false;
        }

        public static boolean isArmstrongNumber(int value) {
            int sum = 0;
            int original = value;
            int length = String.valueOf(value).length();
            while (value != 0) {
            int digit = value % 10;
            sum += Math.pow(digit, length);
            value /= 10;
            }
            return sum == original;
        }

        public static boolean isArmstrongNumber(long value) {
            long sum = 0;
            long original = value;
            int length = String.valueOf(value).length();
            while (value != 0) {
            long digit = value % 10;
            sum += Math.pow(digit, length);
            value /= 10;
            }
            return sum == original;
        }

        public static boolean isArmstrongNumber(short value) {
            short sum = 0;
            short original = value;
            int length = String.valueOf(value).length();
            while (value != 0) {
            short digit = (short) (value % 10);
            sum += Math.pow(digit, length);
            value /= 10;
            }
            return sum == original;
        }

        public static boolean isArmstrongNumber(byte value) {
            byte sum = 0;
            byte original = value;
            int length = String.valueOf(value).length();
            while (value != 0) {
            byte digit = (byte) (value % 10);
            sum += Math.pow(digit, length);
            value /= 10;
            }
            return sum == original;
        }

        public static boolean isArmstrongNumber(double value) {
            int sum = 0;
            int original = (int) value;
            int length = String.valueOf(value).length();
            while (value != 0) {
            int digit = (int) (value % 10);
            sum += Math.pow(digit, length);
            value /= 10;
            }
            return sum == original;
        }

        public static boolean isArmstrongNumber(float value) {
            int sum = 0;
            int original = (int) value;
            int length = String.valueOf(value).length();
            while (value != 0) {
            int digit = (int) (value % 10);
            sum += Math.pow(digit, length);
            value /= 10;
            }
            return sum == original;
        }

        public static boolean isHarshadNumber(int value) {
            int sum = 0;
            int original = value;
            while (value != 0) {
            int digit = value % 10;
            sum += digit;
            value /= 10;
            }
            return original % sum == 0;
        }

        public static boolean isHarshadNumber(long value) {
            long sum = 0;
            long original = value;
            while (value != 0) {
            long digit = value % 10;
            sum += digit;
            value /= 10;
            }
            return original % sum == 0;
        }

        public static boolean isHarshadNumber(short value) {
            short sum = 0;
            short original = value;
            while (value != 0) {
            short digit = (short) (value % 10);
            sum += digit;
            value /= 10;
            }
            return original % sum == 0;
        }

        public static boolean isHarshadNumber(byte value) {
            byte sum = 0;
            byte original = value;
            while (value != 0) {
            byte digit = (byte) (value % 10);
            sum += digit;
            value /= 10;
            }
            return original % sum == 0;
        }

        public static boolean isHarshadNumber(double value) {
            int sum = 0;
            int original = (int) value;
            while (value != 0) {
            int digit = (int) (value % 10);
            sum += digit;
            value /= 10;
            }
            return original % sum == 0;
        }

        public static boolean isHarshadNumber(float value) {
            int sum = 0;
            int original = (int) value;
            while (value != 0) {
            int digit = (int) (value % 10);
            sum += digit;
            value /= 10;
            }
            return original % sum == 0;
        }

        public static boolean isAutomorphicNumber(int value) {
            int square = value * value;
            return Integer.toString(square).endsWith(Integer.toString(value));
        }

        public static boolean isAutomorphicNumber(long value) {
            long square = value * value;
            return Long.toString(square).endsWith(Long.toString(value));
        }

        public static boolean isAutomorphicNumber(short value) {
            short square = (short) (value * value);
            return Short.toString(square).endsWith(Short.toString(value));
        }

        public static boolean isAutomorphicNumber(byte value) {
            byte square = (byte) (value * value);
            return Byte.toString(square).endsWith(Byte.toString(value));
        }

        public static boolean isAutomorphicNumber(double value) {
            int square = (int) (value * value);
            return Integer.toString(square).endsWith(Integer.toString((int) value));
        }

        public static boolean isAutomorphicNumber(float value) {
            int square = (int) (value * value);
            return Integer.toString(square).endsWith(Integer.toString((int) value));
        }

        public static boolean isDuckNumber(String value) {
            return value.substring(1).contains("0") && value.charAt(0) != '0';
        }

        public static boolean isDuckNumber(int value) {
            return isDuckNumber(Integer.toString(value));
        }

        public static boolean isDuckNumber(long value) {
            return isDuckNumber(Long.toString(value));
        }

        public static boolean isDuckNumber(short value) {
            return isDuckNumber(Short.toString(value));
        }

        public static boolean isDuckNumber(byte value) {
            return isDuckNumber(Byte.toString(value));
        }

        public static boolean isDuckNumber(double value) {
            return isDuckNumber(Double.toString(value));
        }

        public static boolean isDuckNumber(float value) {
            return isDuckNumber(Float.toString(value));
        }

        public static boolean isPronicNumber(int value) {
            for (int i = 0; i <= Math.sqrt(value); i++) {
            if (i * (i + 1) == value) {
                return true;
            }
            }
            return false;
        }

        public static boolean isPronicNumber(long value) {
            for (long i = 0; i <= Math.sqrt(value); i++) {
            if (i * (i + 1) == value) {
                return true;
            }
            }
            return false;
        }

        public static boolean isPronicNumber(short value) {
            for (short i = 0; i <= Math.sqrt(value); i++) {
            if (i * (i + 1) == value) {
                return true;
            }
            }
            return false;
        }

        public static boolean isPronicNumber(byte value) {
            for (byte i = 0; i <= Math.sqrt(value); i++) {
            if (i * (i + 1) == value) {
                return true;
            }
            }
            return false;
        }

        public static boolean isPronicNumber(double value) {
            for (int i = 0; i <= Math.sqrt(value); i++) {
            if (i * (i + 1) == value) {
                return true;
            }
            }
            return false;
        }

        public static boolean isPronicNumber(float value) {
            for (int i = 0; i <= Math.sqrt(value); i++) {
            if (i * (i + 1) == value) {
                return true;
            }
            }
            return false;
        }

        
}
