CREATE TABLE Cinemas (
    CinemaID INT PRIMARY KEY,
    Name NVARCHAR(100),
    Location NVARCHAR(255),
	RoomQuantity INT
);
CREATE TABLE Rooms (
    RoomID INT PRIMARY KEY,
    CinemaID INT,
    RoomType NVARCHAR(50),
    SeatQuantity INT,
    FOREIGN KEY (CinemaID) REFERENCES Cinemas(CinemaID)
);

CREATE TABLE Movies (
    MovieID INT PRIMARY KEY,
    Title NVARCHAR(100),
    Genre NVARCHAR(50),
    Duration INT
);

CREATE TABLE Showtimes (
    ShowtimeID INT PRIMARY KEY,
    MovieID INT,
    RoomID INT,
    StartTime DATETIME,
    EndTime DATETIME,
    FOREIGN KEY (MovieID) REFERENCES Movies(MovieID),
    FOREIGN KEY (RoomID) REFERENCES Rooms(RoomID)
);

CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name NVARCHAR(100),
    Email NVARCHAR(100),
    PhoneNumber NVARCHAR(15)
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    OrderDate DATETIME
);

CREATE TABLE Tickets (
    TicketID INT PRIMARY KEY,
    ShowtimeID INT,
	OrderID INT,
    SeatNumber INT,
	Price MONEY,
    FOREIGN KEY (ShowtimeID) REFERENCES Showtimes(ShowtimeID),
	FOREIGN KEY (OrderID) REFERENCES Orders(OrderID)
);


CREATE TABLE OrderDetails(
	OrderID INT,
	TicketID INT,
	CustomerID INT,  
	TotalAmount MONEY,
	OrderType VARCHAR(10) CHECK(OrderType IN ('Online', 'Offline'))
)

