--5
use abc;

SELECT DISTINCT	
	MaKH, DiaChi, DT
FROM 
	KhachHang
WHERE
	MaKH NOT IN (
		SELECT MaKH 
		FROM HoaDon 
		WHERE Ngay BETWEEN '2000-06-01' AND '2000-06-30');
	