-- Trigger if tickets for a Show in a Room > seat Quantity of the room
CREATE TRIGGER tr_CheckSeatAvailability
ON Tickets
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    -- Check if the number of tickets for the show in the room exceeds the seat quantity
    IF EXISTS (
        SELECT 1
        FROM Tickets t
        JOIN Showtimes s ON t.ShowtimeID = s.ShowtimeID
        JOIN Rooms r ON s.RoomID = r.RoomID
        WHERE s.ShowtimeID IN (SELECT ShowtimeID FROM inserted)
        GROUP BY r.SeatQuantity
        HAVING COUNT(t.TicketID) > r.SeatQuantity
    )
    BEGIN
        -- If the constraint is violated, raise an error and rollback the transaction
        RAISERROR ('The number of tickets for the show exceeds the seat quantity of the room.', 16, 1);
        ROLLBACK TRANSACTION;
    END
END;



-- TEST TRIGGER

-- Insert data into the Rooms table
INSERT INTO Rooms (RoomID, CinemaID, RoomType, SeatQuantity) VALUES
(1000, 1, 'Loai 1', 5);

-- Insert data into the Showtimes table
INSERT INTO Showtimes (ShowtimeID, MovieID, RoomID, StartTime, EndTime) VALUES
(1000, 1, 1000, '2023-01-01 10:00', '2023-01-01 12:00');

-- Insert data into the Tickets table
INSERT INTO Tickets (TicketID, ShowtimeID, OrderID, SeatNumber, Price) VALUES
(100, 1000, 1, 1, 10),
(200, 1000, 1, 2, 10),
(300, 1000, 1, 3, 10),
(400, 1000, 1, 4, 10),
(500, 1000, 1, 5, 10);


INSERT INTO Tickets (TicketID, ShowtimeID, OrderID, SeatNumber, Price) VALUES
(600, 1000, 1, 6, 10)

