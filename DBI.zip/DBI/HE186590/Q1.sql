

SELECT
	EmployeeID,
	LastName + ' ' + FirstName as 'Full Name',
	DepartmentName
FROM
	Employees
	JOIN 
	Departments ON Employees.DepartmentID = Departments.DepartmentID
WHERE
	LastName LIKE 'A%'
ORDER BY
	LastName, FirstName