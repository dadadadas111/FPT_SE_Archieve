CREATE PROCEDURE GetShowtimesByMovie
    @MovieID INT
AS
BEGIN
    SELECT *
    FROM Showtimes
    WHERE MovieID = @MovieID
END


CREATE PROCEDURE GetUpcomingShowtimes
    @FromDate DATETIME
AS
BEGIN
    SELECT *
    FROM Showtimes
    WHERE StartTime >= @FromDate;
END;


CREATE PROCEDURE GetOnlineCustomers
AS
BEGIN
    SELECT c.CustomerID, c.Name, c.Email, c.PhoneNumber
    FROM Customers c
    INNER JOIN Orders o ON c.CustomerID = o.CustomerID
    WHERE o.OrderType = 'Online';
END;



-- Test proc GetShowtimesByMovie
EXEC GetShowtimesByMovie @MovieID = 20;


-- test proc GetUpcomingShowtimes
EXEC GetUpcomingShowtimes @FromDate = '2023-11-10';


-- test proc GetOnlineCustomers
EXEC GetOnlineCustomers;








