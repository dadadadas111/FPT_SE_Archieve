SELECT    Product.ProductID, Product.Name AS ProductName, Product.Color, Product.SubcategoryID, ProductSubcategory.Name AS SubCategoryName, ProductSubcategory.Category, ProductCostHistory.StartDate, 
                      ProductCostHistory.EndDate, ProductCostHistory.Cost AS HistoryCost
FROM         Product LEFT OUTER JOIN
                      ProductCostHistory ON Product.ProductID = ProductCostHistory.ProductID LEFT OUTER JOIN
                      ProductSubcategory ON Product.SubcategoryID = ProductSubcategory.SubcategoryID
WHERE     (Product.Color = 'black') AND (Product.Name LIKE 'HL%')