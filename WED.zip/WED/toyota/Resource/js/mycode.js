function openNav(){
    let sideNav = document.querySelector('.sidenav');
    sideNav.style.width = '30%'
}

function closeNav(){
    let sideNav = document.querySelector('.sidenav');
    sideNav.style.width = '0'
}