

-- unique_ticket_orderdetails
ALTER TABLE OrderDetails
ADD CONSTRAINT unique_ticket_orderdetails UNIQUE (ticket_id);

-- unique_customer_email
ALTER TABLE Customers
ADD CONSTRAINT unique_customer_email UNIQUE (email);

-- unique_customer_phone_number
ALTER TABLE Customers
ADD CONSTRAINT unique_customer_phone_number UNIQUE (phone_number);


-- showtime_start_before_end
ALTER TABLE Showtimes
ADD CONSTRAINT chk_start_time_before_end_time CHECK (start_time < end_time);






