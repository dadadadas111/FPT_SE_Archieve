

SELECT
	EmployeeID,
	LastName + ' ' + FirstName AS FullName
FROM
	Employees
WHERE
	EmployeeID NOT IN (SELECT EmployeeID FROM JobHistory)


