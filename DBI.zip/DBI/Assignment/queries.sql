-- get online customer 
SELECT c.CustomerID, c.Name, c.Email, c.PhoneNumber
FROM Customers c
INNER JOIN Orders o ON c.CustomerID = o.CustomerID
WHERE o.OrderType = 'Online';


-- get show starts after 10-11-2023
SELECT *
FROM Showtimes
WHERE StartTime >= '2023-11-10';