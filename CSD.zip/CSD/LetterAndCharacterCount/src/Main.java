
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author asus
 */
public class Main {

    public static void main(String[] args) {

        // Step 1. User enter string content
        String content = enterContent();

        // Step 2. get the words list
        String[] words = getWords(content);

        // Step 3. display words count
        displayWordCount(words);

        // Step 4. display characters count
        displayCharCount(words);
    }

    private static String enterContent() {
        String input;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter your content:");
        input = sc.nextLine();

        // loop while input is empty
        while (input.isEmpty()) {
            System.out.println("Empty input. Try again");
            System.out.println("Enter your content:");
            input = sc.nextLine();

        }
        return input;
    }

    private static String[] getWords(String content) {
        StringTokenizer st = new StringTokenizer(content);
        String[] words = new String[st.countTokens()];
        int i = 0;
        // loop if st has more tokens
        while(st.hasMoreTokens()){
            words[i] = st.nextToken();
            i++;
        }
        return words;
    }

    private static void displayWordCount(String[] words) {
        HashMap<String, Integer> wordCount = new HashMap();
        // loop to all elements in words
        for (String word : words) {
            // check if wordCount contains word
            if (wordCount.containsKey(word)){
                int count = wordCount.get(word);
                wordCount.put(word, count+1);
            }
            else{
                wordCount.put(word, 1);
            }
        }
        
        String output = "";
        // loop to all entries in wordCount
        for (Map.Entry<String,Integer> entry : wordCount.entrySet()) {            
            
            String s = entry.getKey() + "=" + entry.getValue();
            output += " " + s + ",";
            
        }
        output = "{" + output.substring(1, output.length()-1) + "}";
        System.out.println(output);
    }

    private static void displayCharCount(String[] words) {
        HashMap<Character, Integer> charCount = new HashMap();
        // loop to all elements in words
        for (String word : words) {
            // loop to all chars in word
            for (char c: word.toCharArray()) {
                // check if charCount contains c
                if (charCount.containsKey(c)){
                    int count = charCount.get(c);
                    charCount.put(c, count+1);
                }
                else {
                    charCount.put(c, 1);
                }
            }
        }
        String output = "";
        
        // loop to all entries in charCount
        for (Map.Entry<Character, Integer> entry : charCount.entrySet()) {
            String s = entry.getKey() + "=" + entry.getValue();
            output += " " + s + ",";
            
        }
        
        output = "{" + output.substring(1, output.length() - 1) + "}";
        System.out.println(output);
    }

}
