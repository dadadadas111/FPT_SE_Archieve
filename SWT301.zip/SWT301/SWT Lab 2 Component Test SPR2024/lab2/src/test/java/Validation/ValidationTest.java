/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Validation;

import _validation.Validation;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 *
 * @author asus
 */
public class ValidationTest {
    
    public ValidationTest() {
    }

    /**
     * Test of isPositive method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "0, false",
        "-1, false",
    })
    public void testIsPositive(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result1 = Validation.isPositive(value);
        assertEquals(expResult, result1);
        boolean result2 = Validation.isPositive(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isPositive(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result4 = Validation.isPositive(Float.parseFloat(value));
        assertEquals(expResult, result4);
        boolean result5 = Validation.isPositive(Double.parseDouble(value));
        assertEquals(expResult, result5);
        boolean result6 = Validation.isPositive(Short.parseShort(value));
        assertEquals(expResult, result6);
        boolean result7 = Validation.isPositive(Byte.parseByte(value));
        assertEquals(expResult, result7);
    }

    /**
     * Test of isNegative method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, false",
        "0, false",
        "-1, true",
    })
    public void testIsNegative(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result1 = Validation.isNegative(value);
        assertEquals(expResult, result1);
        boolean result2 = Validation.isNegative(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isNegative(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result4 = Validation.isNegative(Float.parseFloat(value));
        assertEquals(expResult, result4);
        boolean result5 = Validation.isNegative(Double.parseDouble(value));
        assertEquals(expResult, result5);
        boolean result6 = Validation.isNegative(Short.parseShort(value));
        assertEquals(expResult, result6);
        boolean result7 = Validation.isNegative(Byte.parseByte(value));
        assertEquals(expResult, result7);
    }

    /**
     * Test of isNonNegative method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "0, true",
        "-1, false",
    })
    public void testIsNonNegative(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result1 = Validation.isNonNegative(value);
        assertEquals(expResult, result1);
        boolean result2 = Validation.isNonNegative(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isNonNegative(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result4 = Validation.isNonNegative(Float.parseFloat(value));
        assertEquals(expResult, result4);
        boolean result5 = Validation.isNonNegative(Double.parseDouble(value));
        assertEquals(expResult, result5);
        boolean result6 = Validation.isNonNegative(Short.parseShort(value));
        assertEquals(expResult, result6);
        boolean result7 = Validation.isNonNegative(Byte.parseByte(value));
        assertEquals(expResult, result7);
    }

    /**
     * Test of isNonPositive method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, false",
        "0, true",
        "-1, true",
    })
    public void testIsNonPositive(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result1 = Validation.isNonPositive(value);
        assertEquals(expResult, result1);
        boolean result2 = Validation.isNonPositive(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isNonPositive(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result4 = Validation.isNonPositive(Float.parseFloat(value));
        assertEquals(expResult, result4);
        boolean result5 = Validation.isNonPositive(Double.parseDouble(value));
        assertEquals(expResult, result5);
        boolean result6 = Validation.isNonPositive(Short.parseShort(value));
        assertEquals(expResult, result6);
        boolean result7 = Validation.isNonPositive(Byte.parseByte(value));
        assertEquals(expResult, result7);
    }

    /**
     * Test of isEven method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, false",
        "0, true",
        "-1, false",
    })
    public void testIsEven(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result2 = Validation.isEven(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isEven(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result7 = Validation.isEven(Byte.parseByte(value));
        assertEquals(expResult, result7);
    }

    /**
     * Test of isOdd method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "0, false",
        "-1, true",
    })
    public void testIsOdd(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result2 = Validation.isOdd(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isOdd(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result6 = Validation.isOdd(Short.parseShort(value));
        assertEquals(expResult, result6);
        boolean result7 = Validation.isOdd(Byte.parseByte(value));
        assertEquals(expResult, result7);
    }

    /**
     * Test of isPrime method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, false",
        "2, true",
        "3, true",
        "4, false",
        "5, true",
        "6, false",
        "7, true",
        "8, false",
        "9, false",
        "10, false",
    })
    public void testIsPrime(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result2 = Validation.isPrime(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isPrime(Long.parseLong(value));
        assertEquals(expResult, result3);
    }

    /**
     * Test of isPalindrome method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "11, true",
        "121, true",
        "123, false",
        "12321, true",
        "12345, false",
    })
    public void testIsPalindrome(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result1 = Validation.isPalindrome(value);
        assertEquals(expResult, result1);
        boolean result2 = Validation.isPalindrome(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isPalindrome(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result6 = Validation.isPalindrome(Short.parseShort(value));
        assertEquals(expResult, result6);
    }

    /**
     * Test of isPerfectSquare method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "4, true",
        "9, true",
        "16, true",
        "25, true",
        "36, true",
        "49, true",
        "64, true",
        "81, true",
        "100, true"
    })
    public void testIsPerfectSquare(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result2 = Validation.isPerfectSquare(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isPerfectSquare(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result4 = Validation.isPerfectSquare(Float.parseFloat(value));
        assertEquals(expResult, result4);
        boolean result5 = Validation.isPerfectSquare(Double.parseDouble(value));
        assertEquals(expResult, result5);
        boolean result6 = Validation.isPerfectSquare(Short.parseShort(value));
        assertEquals(expResult, result6);
        boolean result7 = Validation.isPerfectSquare(Byte.parseByte(value));
        assertEquals(expResult, result7);
    }

    /**
     * Test of isPerfectCube method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "8, true",
        "27, true",
        "61, false",
        "125, true",
        "216, true",
        "343, true",
        "512, true",
        "729, true",
        "1000, true"
    })
    public void testIsPerfectCube(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result2 = Validation.isPerfectCube(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isPerfectCube(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result4 = Validation.isPerfectCube(Float.parseFloat(value));
        assertEquals(expResult, result4);
        boolean result5 = Validation.isPerfectCube(Double.parseDouble(value));
        assertEquals(expResult, result5);
        boolean result6 = Validation.isPerfectCube(Short.parseShort(value));
        assertEquals(expResult, result6);
    }

    /**
     * Test of isPerfectPower method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "4, true",
        "9, true",
        "16, true",
        "25, true",
        "36, true",
        "49, true",
        "64, true",
        "81, true",
        "100, true"
    })
    public void testIsPerfectPower(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result2 = Validation.isPerfectPower(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isPerfectPower(Long.parseLong(value));
        assertEquals(expResult, result3);
        boolean result4 = Validation.isPerfectPower(Float.parseFloat(value));
        assertEquals(expResult, result4);
        boolean result5 = Validation.isPerfectPower(Double.parseDouble(value));
        assertEquals(expResult, result5);
        boolean result6 = Validation.isPerfectPower(Short.parseShort(value));
        assertEquals(expResult, result6);
        boolean result7 = Validation.isPerfectPower(Byte.parseByte(value));
        assertEquals(expResult, result7);
    }

    /**
     * Test of isArmstrongNumber method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "153, true",
        "370, true",
        "9474, true",
        "9475, false"
    })
    public void testIsArmstrongNumber(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result2 = Validation.isArmstrongNumber(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isArmstrongNumber(Long.parseLong(value));
        assertEquals(expResult, result3);
    }

    /**
     * Test of isHarshadNumber method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "18, true",
        "19, false",
        "20, true",
        "21, true",
        "22, false",
        "23, false",
        "24, true",
        "25, false",
        "26, false"
    })
    public void testIsHarshadNumber(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result2 = Validation.isHarshadNumber(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isHarshadNumber(Long.parseLong(value));
        assertEquals(expResult, result3);
    }

    /**
     * Test of isAutomorphicNumber method, of class Validation.
     */
    @ParameterizedTest
    @CsvSource({
        "1, true",
        "5, true",
        "25, true",
        "76, true",
        "625, true",
        "9376, true"
    })
    public void testIsAutomorphicNumber(String value, boolean expResult) {
        // test if value is String, int, long, float, double, short, byte
        boolean result2 = Validation.isAutomorphicNumber(Integer.parseInt(value));
        assertEquals(expResult, result2);
        boolean result3 = Validation.isAutomorphicNumber(Long.parseLong(value));
        assertEquals(expResult, result3);
    }
}
