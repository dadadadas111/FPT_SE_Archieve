

create table Employees (
	ID int Primary key,
	Name nvarchar(30)
)

create table Products (
	Code int primary key,
	Name nvarchar(30),
	Price float

)

create table Sale(
	ID int references Employees(ID),
	Code int references Products(Code),
	Date date
)