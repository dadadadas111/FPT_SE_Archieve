/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fibonacci45;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Main {

    public static void main(String[] args) {
        boolean test = false;
        
        
        // Step 1. get 45 fibonacci numbers
        int[] fibonacciNumbers = get45FibonacciNumbers();
        
        // Step 2. display result
        displayResult(fibonacciNumbers, test);
        
        
        
        Scanner sc = new Scanner(System.in);
        sc.nextLine();
    }

    private static int[] get45FibonacciNumbers() {        
        
        int[] arr = new int[45];
        
        findFibonacciNumber(arr, 0, 44);
        
        return arr;
        
    }
    
    private static void findFibonacciNumber(int[] arr, int i, int j) {
        
        
        // check if i > j 
        if (i > j) {
            return;
        }
        
        // check i value
        switch (i) {
            case 0:
                arr[i] = 0;
                break;
                
            case 1:
                arr[i] = 1;
                break;
                
            default:
                arr[i] = arr[i-1] + arr[i-2];
        }
        
        
        findFibonacciNumber(arr, i+1, j);
        
    }

    private static void displayResult(int[] arr, boolean test) {
        System.out.println("The 45 sequence fibonacci:");
        
        String output = "";
        
        // loop to all elements in list
        for (int i = 0; i < arr.length; i++) {
            
            // check if test is false
            if (test == false){
                
                output += " " + arr[i] + ",";
            }
            // if test is true
            else {
                
                
                output += "\n" + (i+1) + ". " + arr[i] ;
                
                // check if i >= 2
                if (i >= 2){
                    
                    output +=" = " + arr[i-1] + " + " + arr[i-2] + " ";
                }
            }
            
        }
        
        System.out.println(output.substring(1, output.length() - 1));
    }

    
    

}
