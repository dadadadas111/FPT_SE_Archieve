/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayqueue;

/**
 *
 * @author asus
 */
public class LinkedPriorityQueue {
    Node top;

    public LinkedPriorityQueue() {
    }
    
    public boolean isEmpty(){
        return top == null;
    }
    public void enqueue( int x){
        if (isEmpty() ){
            top = new Node(x);
        }
        Node p = top;
        while ( (int)p.info > x && p.next != null && (int)p.next.info > x ){
            p = p.next;
        }
        p.next = new Node(x, p.next);
    }
    
    public Object dequeue(){
        if (isEmpty()){
            return null;
        }
        int x = (int)top.info;
        top = top.next;
        return x;
    }
    public Object front(){
        if (isEmpty()){
            return null;
        }
        return top.info;
    }
}
