/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraystack;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asus
 */
public class ArrayStack {

    int max_size;
    int top;
    Object[] list;

    public ArrayStack(int max_size) {
        this.max_size = max_size;
        list = new Object[max_size];
        top = -1;
    }

    public ArrayStack() {
        max_size = Integer.MAX_VALUE;
        list = new Object[max_size];
        top = -1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == max_size - 1;
    }

    public void clear() {
        top = -1;
    }

    public boolean grow() {
        int new_max_size = max_size + max_size / 2;
        Object[] temp = new Object[new_max_size];
        if (temp == null) {
            return false;
        }
        for (int i = 0; i <= top; i++) {
            temp[i] = list[i];

        }
        max_size = new_max_size;
        list = temp;
        return true;
    }

    public void push(Object O) {
        if (isFull()) {
            boolean grow = grow();
            if (!grow) {
                System.out.println("Failed");
                return;
            }
        }
        list[++top] = O;
    }

    public Object peek() {
        if (isEmpty()) {
            System.out.println("Empty stack.");
            return null;
        }
        return list[top];
    }

    public Object pop() {
        if (isEmpty()) {
            System.out.println("Empty stack.");
            return null;
        }
        top--;
        return list[top + 1];
    }

    public int search(Object x) {
        for (int i = 0; i <= top; i++) {
            if (list[i].equals(x)) {
                return i;
            }
        }
        return -1;
    }

    public void input(int n) {
        for (int i = 0; i < n; i++) {
            push(i);
        }
    }

    public void output() {
        if (isEmpty()) {
            System.out.println("Empty stack");
            return;
        }
        while (!isEmpty()) {
            System.out.print(pop() + " ");
        }
    }

    public void toBinary(int x) {
        clear();
        do {
            push(x % 2);
            x /= 2;
        } while (x != 0);
        output();
    }

    public static void main(String[] args) {
        ArrayStack st = new ArrayStack(20);
//        st.input(15);
//        System.out.println(st.search(14));
//        st.output();
        st.toBinary(8);
    }

}
