function changeOrder() {
    let customer = document.getElementById('customer');
    let shop = document.getElementById('shop');

    let order = customer.querySelectorAll('p');
    order.forEach(element => {
        customer.removeChild(element);
    });

    order = shop.querySelectorAll('.item');

    order.forEach(element => {
        let input = element.querySelector('input');
        let name = element.querySelector('.name');
        if (input.checked) {
            let p = document.createElement('p');
            p.innerText = name.innerText;
            customer.appendChild(p);

        }
    });

}

function CalTotal() {

    changeOrder();
    let shop = document.getElementById('shop');
    let customer = document.getElementById('customer');
    let total = 0;

    order = shop.querySelectorAll('.item');

    order.forEach(element => {
        let input = element.querySelector('input');
        let name = element.querySelector('.name');
        if (input.checked) {
            total += 1.0*element.dataset.value;
            console.log(total);
        }
    });

    let p = document.createElement('p');
    p.id = 'total';
    p.innerText = 'Total Amount: ' + total + '$';
    console.log(p)
    customer.appendChild(p);

}