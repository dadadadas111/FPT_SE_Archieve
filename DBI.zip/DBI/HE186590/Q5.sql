

SELECT
	DepartmentName,
	COUNT(*) AS 'Total Emps'
FROM
	Departments d
	JOIN Employees e ON d.DepartmentID = e.DepartmentID

GROUP BY
	DepartmentName
HAVING
	COUNT(*) > 5
ORDER BY
	[Total Emps]
