
use Northwind;

-- 1

SELECT
	LOWER(LastName + ' ' + FirstName) as 'Full name',
	titleOfCourtesy
FROM
	Employees;


-- 2

SELECT
	UPPER(LastName + ' ' + FirstName) as 'Full name'
FROM
	Employees;

-- 3

SELECT
	EmployeeID,
	LastName,
	FirstName,
	Title,
	City,
	Country
FROM
	Employees
WHERE 
	Country = 'USA';

-- 4

SELECT
	CustomerID, 
	CompanyName,
	ContactName,
	ContactTitle,
	Country
FROM	
	Customers
WHERE
	Country = 'UK';

-- 5

SELECT
	CustomerID,
	CompanyName,
	phone,
	address,
	city,
	Country

FROM
	Customers
WHERE 
	Country = 'Mexico';

-- 6

SELECT
	CustomerID,
	CompanyName,
	phone,
	address,
	city,
	Country

FROM
	Customers
WHERE 
	Country = 'Sweden';

-- 7
SELECT
	productid,
	productName,
	Unitprice,
	UnitsInStock

FROM
	[Products]
WHERE
	UnitsInStock BETWEEN 5 AND 10;

-- 8
SELECT
	[ProductID],
	ProductName,
	unitprice,
	reorderlevel,
	UnitsOnOrder
FROM
	Products
WHERE
	UnitsOnOrder BETWEEN 60 AND 100;

-- 9
SELECT 
	e.EmployeeID,
	LastName,
	FirstName,
	Title,
	'1996' AS year,
	COUNT(*) AS 'total orders'
FROM
	Employees e
		JOIN
	Orders o ON e.EmployeeID = o.EmployeeID
WHERE
	OrderDate BETWEEN '1996-01-01' AND '1996-12-31'
GROUP BY
	e.EmployeeID,
	LastName,
	FirstName,
	Title;

-- 10
SELECT DISTINCT
	e.EmployeeID,
	LastName,
	FirstName,
	City,
	Country,
	COUNT(e.EmployeeID) AS 'total orders'
FROM
	Employees e
		JOIN
	Orders o ON e.EmployeeID = o.EmployeeID
WHERE
	OrderDate BETWEEN '1998-01-01' AND '1998-12-31'
GROUP BY
	e.EmployeeID,
	LastName,
	FirstName,
	City,
	Country;

-- 11
SELECT DISTINCT
	e.EmployeeID,
	LastName,
	FirstName,
	hiredate,
	COUNT(e.EmployeeID) AS 'total orders'
FROM
	Employees e
		JOIN
	Orders o ON e.EmployeeID = o.EmployeeID
WHERE
	OrderDate BETWEEN '1998-01-01' AND '1998-07-31'
GROUP BY
	e.EmployeeID,
	LastName,
	FirstName,
	hiredate;

-- 12

SELECT DISTINCT
	e.EmployeeID,
	LastName,
	FirstName,
	hiredate,
	homephone,
	COUNT(e.EmployeeID) AS 'total orders'
FROM
	Employees e
		JOIN
	Orders o ON e.EmployeeID = o.EmployeeID
WHERE
	OrderDate BETWEEN '1997-01-01' AND '1997-06-30'
GROUP BY
	e.EmployeeID,
	LastName,
	FirstName,
	hiredate,
	HomePhone;

-- 13

SELECT 
	OrderID,
	DAY(OrderDate) AS OrderDay,
	MONTH(OrderDate) AS OrderMonth,
	YEAR(OrderDate) AS OrderYear,
	Freight,
	CASE	
		WHEN Freight >= 100 THEN '10%'
		ELSE '5%'
	END AS tax,
	CASE	
		WHEN Freight >= 100 THEN Freight * 1.1
		ELSE Freight * 1.05
	END AS [Freight with tax]

FROM
	Orders
WHERE 
	OrderDate BETWEEN '1996-08-01' AND '1996-08-05';

-- 14

SELECT 
	LastName + ' ' + FirstName AS [Full name],
	titleOfCourtesy,
	'Male' AS Sex
FROM
	Employees

WHERE TitleOfCourtesy = 'Mr.'

UNION ALL

SELECT 
	LastName + ' ' + FirstName AS [Full name],
	titleOfCourtesy,
	'Female' AS Sex
FROM
	Employees

WHERE TitleOfCourtesy IN ('Mrs.', 'Ms.')

-- 15

SELECT
	LastName + ' ' + FirstName AS 'full name',
	titleofcourtesy,
	'M' AS sex
FROM
	Employees
WHERE	
	TitleOfCourtesy IN ('Dr.', 'Mr.')

	UNION ALL

SELECT
	LastName + ' ' + FirstName AS 'full name',
	titleofcourtesy,
	'F' AS sex
FROM
	Employees
WHERE	
	TitleOfCourtesy IN ('Mrs.', 'Ms.')


-- 16
SELECT 
	LastName + ' ' + FirstName AS [full name],
	titleofcourtesy,
	'Male' AS sex
FROM
	Employees

WHERE TitleOfCourtesy = 'Mr.'

UNION ALL

SELECT 
	LastName + ' ' + FirstName AS [full name],
	titleofcourtesy,
	'Female' AS sex
FROM
	Employees

WHERE TitleOfCourtesy IN ('Mrs.', 'Ms.')

UNION ALL

SELECT 
	LastName + ' ' + FirstName AS [full name],
	titleofcourtesy,
	'Unknown' AS sex
FROM
	Employees

WHERE TitleOfCourtesy NOT IN ('Mrs.', 'Ms.', 'Mr.')

-- 17

SELECT 
	LastName + ' ' + FirstName AS [full name],
	titleofcourtesy,
	1 AS sex
FROM
	Employees

WHERE TitleOfCourtesy = 'Mr.'

UNION ALL

SELECT 
	LastName + ' ' + FirstName AS [full name],
	titleofcourtesy,
	0 AS sex
FROM
	Employees

WHERE TitleOfCourtesy IN ('Mrs.', 'Ms.')

UNION ALL

SELECT 
	LastName + ' ' + FirstName AS [full name],
	titleofcourtesy,
	2 AS sex
FROM
	Employees

WHERE TitleOfCourtesy NOT IN ('Mrs.', 'Ms.', 'Mr.')


-- 18

SELECT 
	LastName + ' ' + FirstName AS [full name],
	titleofcourtesy,
	'M' AS sex
FROM
	Employees

WHERE TitleOfCourtesy = 'Mr.'

UNION ALL

SELECT 
	LastName + ' ' + FirstName AS [full name],
	titleofcourtesy,
	'F' AS sex
FROM
	Employees

WHERE TitleOfCourtesy IN ('Mrs.', 'Ms.')

UNION ALL

SELECT 
	LastName + ' ' + FirstName AS [full name],
	titleofcourtesy,
	'N/A' AS sex
FROM
	Employees

WHERE TitleOfCourtesy NOT IN ('Mrs.', 'Ms.', 'Mr.')


-- 19

SELECT 
	OrderID,
	o.CustomerID,
	CompanyName,
	ContactName,
	Country,
	EmployeeID,
	OrderDate
FROM
	Orders o
	JOIN Customers c ON o.CustomerID = c.CustomerID
WHERE
	Country = 'USA';


-- 21

SELECT
	p.CategoryID,
	CategoryName,
	p.ProductID,
	ProductName,
	DAY(OrderDate) AS day,
	MONTH(OrderDate) AS month,
	YEAR(OrderDate) AS year,
	ROUND(Quantity * od.UnitPrice, 2) AS Revenue


FROM
	Products p
	JOIN
	Categories c ON p.CategoryID = c.CategoryID 
	JOIN 
	[Order Details] od ON od.ProductID = p.ProductID
	JOIN 
	Orders o ON o.OrderID = od.OrderID
WHERE
	OrderDate BETWEEN '1996-07-01' AND '1996-07-05'
ORDER BY
	p.CategoryID ASC,
	p.ProductID ASC

-- 22

SELECT
	o.EmployeeID,
	LastName,
	FirstName,
	OrderID,
	OrderDate,
	RequiredDate,
	ShippedDate
FROM
	Employees e
	JOIN Orders o ON o.EmployeeID = e.EmployeeID
WHERE
	DATEDIFF(day, RequiredDate, ShippedDate) > 7
ORDER BY
	o.EmployeeID,
	OrderID;

-- 23

SELECT
	CompanyName, 
	Phone
FROM
	Customers
WHERE 
	CompanyName LIKE 'W%'

UNION ALL

SELECT
	LastName + ' ' + FirstName AS CompanyName,
	HomePhone AS Phone
FROM
	Employees

-- 24

SELECT
	CustomerID,
	CompanyName,
	ContactName,
	ContactTitle
FROM
	Customers
WHERE 
	CustomerID = (
	SELECT CustomerID
	FROM Orders
	WHERE OrderID = '10643'
	)

-- 25

SELECT
	o.ProductID,
	ProductName,
	SUM(Quantity) AS [Total Ordered]
FROM
	Products p
	JOIN [Order Details] o ON p.ProductID = o.ProductID

GROUP BY
	o.ProductID,
	ProductName
HAVING
	SUM(Quantity) >= 1200
ORDER BY
	[Total Ordered]

-- 26

SELECT
	o.ProductID,
	ProductName,
	SupplierID,
	CategoryID,
	SUM(Quantity) AS [Total ordered]
FROM
	Products p
	JOIN [Order Details] o ON p.ProductID = o.ProductID

GROUP BY
	o.ProductID,
	SupplierID,
	CategoryID,
	ProductName
HAVING
	SUM(Quantity) >= 1400
ORDER BY
	[Total ordered] DESC

-- 27
WITH totalProducts AS(
	SELECT 
		c.CategoryID,
		CategoryName,
		COUNT(p.CategoryID) AS 'Total product'
	FROM
		Categories c
		JOIN Products p ON c.CategoryID = p.CategoryID
	GROUP BY
		c.CategoryID,
		CategoryName
)

SELECT *
FROM
	totalProducts 
WHERE
	[Total product] >= ALL(SELECT [Total product] FROM totalProducts)



-- 28

WITH totalProducts AS(
	SELECT 
		c.CategoryID,
		CategoryName,
		COUNT(p.CategoryID) AS 'Total product'
	FROM
		Categories c
		LEFT JOIN Products p ON c.CategoryID = p.CategoryID
	GROUP BY
		c.CategoryID,
		CategoryName

)

SELECT *
FROM
	totalProducts 
WHERE
	[Total product] <= ALL(SELECT [Total product] FROM totalProducts)

-- 29

SELECT
	(SELECT COUNT(*) FROM Customers)
	+ (SELECT COUNT(*) FROM Employees) AS 'Total records'

-- 30

WITH EmployeeOrders AS(
	SELECT
		e.EmployeeID,
		COUNT(*) AS 'total orders'
	FROM
		Employees e
		JOIN Orders o ON e.EmployeeID = o.EmployeeID
	GROUP BY
		e.EmployeeID
)

SELECT 
	e.EmployeeID,
	LastName,
	FirstName,
	Title,
	[total orders]
FROM
	Employees e
	JOIN EmployeeOrders eo ON e.EmployeeID = eo.EmployeeID
WHERE
	[total orders] <= ALL (SELECT [total orders] FROM EmployeeOrders);

-- 31

WITH EmployeeOrders AS(
	SELECT
		e.EmployeeID,
		COUNT(*) AS 'total orders'
	FROM
		Employees e
		JOIN Orders o ON e.EmployeeID = o.EmployeeID
	GROUP BY
		e.EmployeeID
)

SELECT 
	e.EmployeeID,
	LastName,
	FirstName,
	Title,
	[total orders]
FROM
	Employees e
	JOIN EmployeeOrders eo ON e.EmployeeID = eo.EmployeeID
WHERE
	[total orders] >= (SELECT MAX( [total orders]) FROM EmployeeOrders);


-- 32

SELECT
	ProductID,
	ProductName,
	SupplierID,
	CategoryID,
	UnitsInStock
FROM
	Products
WHERE
	UnitsInStock >= (SELECT MAX(UnitsInStock) FROM Products);

-- 33
SELECT
	ProductID,
	ProductName,
	SupplierID,
	CategoryID,
	UnitsInStock
FROM
	Products
WHERE
	UnitsInStock <= (SELECT MIN(UnitsInStock) FROM Products);

	
-- 34

SELECT
	ProductID,
	ProductName,
	SupplierID,
	CategoryID,
	UnitsOnOrder
FROM
	Products
WHERE
	UnitsOnOrder = (SELECT MAX(UnitsOnOrder) FROM Products);


-- 35
SELECT
	ProductID,
	ProductName,
	SupplierID,
	CategoryID,
	reorderlevel
FROM
	Products
WHERE
	reorderlevel >= (SELECT MAX(reorderlevel) FROM Products);

-- 36
WITH DelayedCount AS (
SELECT
	e.EmployeeID,
	LastName,
	FirstName,
	SUM(
		CASE
			WHEN DATEDIFF(day, RequiredDate, ShippedDate) > 0 THEN 1
			ELSE 0
		END
	) AS 'Delayed Orders'
FROM
	Employees e JOIN Orders o ON e.EmployeeID = o.EmployeeID
GROUP BY
	e.EmployeeID,
	LastName,
	FirstName
)

SELECT *
FROM 
	DelayedCount
WHERE
	[Delayed Orders] = (SELECT MAX([Delayed Orders]) FROM DelayedCount);

-- 37
WITH DelayedCount AS (
SELECT
	e.EmployeeID,
	LastName,
	FirstName,
	SUM(
		CASE
			WHEN DATEDIFF(day, RequiredDate, ShippedDate) > 0 THEN 1
			ELSE 0
		END
	) AS 'Delayed Orders'
FROM
	Employees e JOIN Orders o ON e.EmployeeID = o.EmployeeID
GROUP BY
	e.EmployeeID,
	LastName,
	FirstName
)

SELECT *
FROM 
	DelayedCount
WHERE
	[Delayed Orders] = GREATEST((SELECT MIN([Delayed Orders]) FROM DelayedCount), 1);


-- 38

SELECT *
FROM
	(
SELECT TOP 3
	p.ProductID,
	ProductName,
	SUM(Quantity) AS 'Total Ordered'
FROM
	Products p 
	JOIN [Order details] o ON p.ProductID = o.ProductID
GROUP BY
	p.ProductID,
	ProductName
ORDER BY
	[Total Ordered] DESC
	) t
ORDER BY
	[Total Ordered] ASC;

-- 39

SELECT *
FROM
	(
SELECT TOP 5
	p.ProductID,
	ProductName,
	SUM(Quantity) AS 'Total Ordered'
FROM
	Products p 
	JOIN [Order details] o ON p.ProductID = o.ProductID
GROUP BY
	p.ProductID,
	ProductName
ORDER BY
	[Total Ordered] DESC
	) t
ORDER BY
	[Total Ordered] ASC;


-- 40
