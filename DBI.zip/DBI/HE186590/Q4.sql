

SELECT
	EmployeeID,
	LastName + ' ' + FirstName AS FullName,
	DepartmentName AS Department,
	Salary
FROM
	Departments d
	JOIN Employees e ON e.DepartmentID = d.DepartmentID
WHERE
	DepartmentName = 'IT'
ORDER BY
	FullName