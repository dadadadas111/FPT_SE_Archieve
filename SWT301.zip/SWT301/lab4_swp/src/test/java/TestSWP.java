import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.nio.file.Paths;
import java.time.Duration;


import static org.junit.jupiter.api.Assertions.*;

public class TestSWP {

    private ChromeDriver driver;
    private WebDriverWait wait;

    @BeforeEach
    public void setUp() {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\asus\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(30)); // Timeout
        driver.manage().window().maximize();
        driver.get("http://localhost:8080/app/home?action=login");

        try {
            // Wait for email field to be visible and enter email
            WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
            emailField.sendKeys("long6athcskl@gmail.com");

            // Wait for password field to be visible and enter password
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("password")));
            passwordField.sendKeys("Group4swp");

            // Wait for login button to be clickable and click it
            WebElement btnLogin = wait.until(ExpectedConditions.elementToBeClickable(By.id("btnLogin")));
            btnLogin.click();

            // Wait for some element on the home page to ensure login was successful
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".header__right-userprofile")));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @DisplayName("Test Change Profile")
    @ParameterizedTest(name = "{index} => Condition={0}, Input Value={1}, Expected Result={2}, Tag={3}")
    @CsvFileSource(resources = "/resources.csv")
    public void testChangeUserProfile(String condition, String inputValue, String expected, String tag, String imagePath) throws InterruptedException {
        try {

            // 1. Click on avatar
            WebElement avatar = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".header__right-userprofile")));
            avatar.click();
            System.out.println("Clicked on avatar");

            // 2. Click on button user profile
            WebElement userProfileButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("profile-button")));
            userProfileButton.click();
            System.out.println("Clicked on user profile button");

            Thread.sleep(1000);

            // NOTE: THIS PART IS FOR CHECKING AVARTAR
            // START

            // Read the old avatar image
            WebElement avatarImg = driver.findElement(By.id("imagePreview"));
            String oldAvatarSrc = avatarImg.getAttribute("src");
            BufferedImage oldImage = ImageIO.read(new URL(oldAvatarSrc));

            // END

            // 3. Select form input and change information
            if ("Full Name".equals(condition)) {
                WebElement fullNameInput = driver.findElement(By.xpath("/html/body/div[4]/div/form/div/div[2]/div[1]/input"));
                fullNameInput.clear();
                fullNameInput.sendKeys(inputValue);
                System.out.println("Updated Full Name");
            } else if ("Gender".equals(condition)) {
                WebElement genderInput = wait.until(ExpectedConditions.elementToBeClickable(By.id(inputValue.equals("F") ? "female" : "male")));
                genderInput.click();
                System.out.println("Updated Gender");
            } else if ("Mobile".equals(condition)) {
                WebElement mobileInput = driver.findElement(By.xpath("/html/body/div[4]/div/form/div/div[2]/div[4]/input"));
                mobileInput.clear();
                mobileInput.sendKeys(inputValue);
                System.out.println("Updated Mobile");
            } else if ("Avatar".equals(condition)) {
                WebElement imageUploadInput = driver.findElement(By.id("imageUpload"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", imageUploadInput);

//                // Read the old avatar image
//                WebElement avatarImg = driver.findElement(By.id("imagePreview"));
//                String oldAvatarSrc = avatarImg.getAttribute("src");
//                BufferedImage oldImage = ImageIO.read(new URL(oldAvatarSrc));

                // Upload the new image
                imageUploadInput.sendKeys(Paths.get(imagePath).toAbsolutePath().toString());
                System.out.println("Updated Avatar");
            }

            Thread.sleep(1000);

            // 4. Submit
            WebElement submitButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".submit_button-profile")));
            submitButton.click();
            System.out.println("Clicked on submit button");

            Thread.sleep(3000);

            // get home again
            driver.get("http://localhost:8080/app/home");

            // 5. Reopen the user profile and check if information has changed
            // Re-click on avatar and user profile button
            avatar = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".header__right-userprofile")));
            avatar.click();
            userProfileButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("profile-button")));
            userProfileButton.click();
            System.out.println("Reopened user profile");

            Thread.sleep(1000);

            if ("Full Name".equals(condition)) {
                WebElement fullNameInput = driver.findElement(By.xpath("/html/body/div[4]/div/form/div/div[2]/div[1]/input"));
                if (expected.equals("Valid")) {
                    assertEquals(inputValue, fullNameInput.getAttribute("value"));
                } else {
                    assertNotEquals(inputValue, fullNameInput.getAttribute("value"));
                }
                System.out.println("Verified Full Name");
            } else if ("Gender".equals(condition)) {
                WebElement genderInput = wait.until(ExpectedConditions.elementToBeClickable(By.id(inputValue.equals("F") ? "female" : "male")));
                if (expected.equals("Valid")) {
                    assertEquals(true, genderInput.isSelected());
                } else {
                    assertNotEquals(true, genderInput.isSelected());
                }
                System.out.println("Verified Gender");
            } else if ("Mobile".equals(condition)) {
                WebElement mobileInput = driver.findElement(By.xpath("/html/body/div[4]/div/form/div/div[2]/div[4]/input"));
                if (expected.equals("Valid")) {
                    assertEquals(inputValue, mobileInput.getAttribute("value"));
                } else {
                    assertNotEquals(inputValue, mobileInput.getAttribute("value"));
                }
                System.out.println("Verified Mobile");
            } else if ("Avatar".equals(condition)) {
                // Read the new avatar image
                WebElement new_avatarImg = driver.findElement(By.id("imagePreview"));
                String newAvatarSrc = new_avatarImg.getAttribute("src");
                BufferedImage newImage = ImageIO.read(new URL(newAvatarSrc));

                // Compare the old and new images
                if (expected.equals("Valid"))
                    assertFalse(areImagesEqual(oldImage, newImage));
                else {
                    assertTrue(areImagesEqual(oldImage, newImage));
                }
                System.out.println("Verified Avatar");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean areImagesEqual(BufferedImage imgA, BufferedImage imgB) {
        if (imgA.getWidth() != imgB.getWidth() || imgA.getHeight() != imgB.getHeight()) {
            return false;
        }

        for (int y = 0; y < imgA.getHeight(); y++) {
            for (int x = 0; x < imgA.getWidth(); x++) {
                if (imgA.getRGB(x, y) != imgB.getRGB(x, y)) {
                    return false;
                }
            }
        }
        return true;
    }

    @AfterEach
    public void closeBrowser() {
        driver.quit();
    }

}
