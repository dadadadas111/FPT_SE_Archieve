SELECT    studentID, studentFName, studentLName, studentGender, studentDOB, studentAddress
FROM         Student
where
	year(studentDOB) = 1990 