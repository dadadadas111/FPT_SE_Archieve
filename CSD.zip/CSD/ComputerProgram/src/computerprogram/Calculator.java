/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computerprogram;

/**
 *
 * @author asus
 */
public class Calculator {

    public static void process() {
        System.out.println("\n----- Normal Calculator -----");
        double num1 = Double.NaN, num2;
        String Op;
        do {
            // check if num1 is NaN 
            if (Double.isNaN(num1)) {
                num1 = Validation.enterDouble("Enter number: ");
            }
            Op = Validation.enterOperator("Enter Operator: ");
            // check if operator is "="
            if (Op.equals("=")) {
                break;
            }
            num2 = Validation.enterDouble("Enter number: ");
            num1 = calculate(num1, Op, num2);
            System.out.println("Memory: " + num1);
        } while (!"=".equals(Op));
        System.out.println("Result: " + num1);

    }

    public static double calculate(double num1, String Op, double num2) {
        try {
            if (Op.equals("/") && num2 == 0) {
                throw new ArithmeticException("Cannot divided by 0");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return num1;
        }

        // check operator
        switch (Op) {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "*":
                return num1 * num2;
            case "/":
                return num1 / num2;
            case "^":
                return Math.pow(num1, num2);
            default:
                return num1;
        }

    }
}
