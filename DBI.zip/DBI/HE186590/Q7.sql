

SELECT
	c.CountryID,
	CountryName,
	COUNT(EmployeeID) AS [Total Employees]
FROM
	Countries c
	LEFT JOIN Locations l ON c.CountryID = l.CountryID
	LEFT JOIN Departments d ON l.LocationID = d.LocationID
	LEFT JOIN Employees e ON d.DepartmentID = e.DepartmentID
GROUP BY
	c.CountryID,
	CountryName
ORDER BY 
	[Total Employees] DESC