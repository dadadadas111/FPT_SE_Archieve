/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bstree;

/**
 *
 * @author asus
 */
public class Node {
    Car info;
    int key;
    Node left, right;

    public Node() {
    }

    public Node(Car info) {
        this.info = info;
        key = info.price;
    }
    public void printKey(){
        System.out.print(info.toString() + " ");
    }

    public Node(Car info, Node left, Node right) {
        this.info = info;
        key = info.price;
        this.left = left;
        this.right = right;
    }
    
}
