
package matrixcalculator;

import java.util.Scanner;

public class Main {

    static MatrixCalculator calculator = new MatrixCalculator();

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int choice;
            do {
                showMenu();
                choice = getChoice("Enter your choice: ", scanner);
                processChoice(choice, scanner);
                
                System.out.println();
            } while (choice != 4);
        }
    }

    private static void showMenu(){
        System.out.println("Matrix Calculator");
        System.out.println("1. Add matrices");
        System.out.println("2. Subtract matrices");
        System.out.println("3. Multiply matrices");
        System.out.println("4. Quit");
    }

    private static int getChoice(String msg, Scanner scanner){
        // Get the choice from the user with error handler
        int choice;
        do {
            System.out.print(msg);
            choice = scanner.nextInt();
            if (choice < 1 || choice > 4) {
                System.out.println("Invalid choice. Please try again.");
            }
        } while (choice < 1 || choice > 4);
        return choice;
    }
    private static void processChoice (int choice, Scanner scanner){
        switch(choice){
            case 1:
                processAddMatrices(scanner);
                break;
            case 2:
                processSubtractMatrices(scanner);
                break;
            case 3:
                processMultiplyMatrices(scanner);
                break;
            case 4:
                System.out.println("Exiting...");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void processAddMatrices(Scanner scanner){
        System.out.println("Enter the dimensions of the matrices:");
        int rows = getInt("Number of rows: ", scanner);
        int columns = getInt("Number of columns: ", scanner);
        System.out.println("Enter the elements of the first matrix:");
        int[][] matrix1 = readMatrix(rows, columns, scanner);
        System.out.println("Enter the elements of the second matrix:");
        int[][] matrix2 = readMatrix(rows, columns, scanner);
        int[][] sum = calculator.addMatrices(matrix1, matrix2);
        System.out.println("The sum of the matrices is:");
        printMatrix(sum);
    }

    private static void processSubtractMatrices(Scanner scanner){
        System.out.println("Enter the dimensions of the matrices:");
        int rows = getInt("Number of rows: ", scanner);
        int columns = getInt("Number of columns: ", scanner);
        System.out.println("Enter the elements of the first matrix:");
        int[][] matrix1 = readMatrix(rows, columns, scanner);
        System.out.println("Enter the elements of the second matrix:");
        int[][] matrix2 = readMatrix(rows, columns, scanner);
        int[][] difference = calculator.subtractMatrices(matrix1, matrix2);
        System.out.println("The difference of the matrices is:");
        printMatrix(difference);
    }

    private static void processMultiplyMatrices(Scanner scanner){
        System.out.println("Enter the dimensions of the matrices:");
        int rows1 = getInt("Number of rows of the first matrix: ", scanner);
        int columns1 = getInt("Number of columns of the first matrix / rows of the second matrix: ", scanner);
        int columns2 = getInt("Number of columns of the second matrix: ", scanner);
        System.out.println("Enter the elements of the first matrix:");
        int[][] matrix1 = readMatrix(rows1, columns1, scanner);
        System.out.println("Enter the elements of the second matrix:");
        int[][] matrix2 = readMatrix(columns1, columns2, scanner);
        int[][] product = calculator.multiplyMatrices(matrix1, matrix2);
        System.out.println("The product of the matrices is:");
        printMatrix(product);
    }


    private static int getInt(String msg, Scanner scanner){
        // Get the integer from the user with error handler
        int number;
        do {
            System.out.print(msg);
            number = scanner.nextInt();
            if (number < 0) {
                System.out.println("Invalid input. Please enter a non-negative integer.");
            }
        } while (number < 0);
        return number;
    }

    private static int[][] readMatrix(int rows, int columns, Scanner scanner) {
        // check condition for rows and columns
        if (rows <= 0 || columns <= 0) {
            throw new IllegalArgumentException("Invalid dimensions for the matrix");
        }
        int[][] matrix = new int[rows][columns];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                matrix[i][j] = getInt("Enter element at position (" + (i + 1) + ", " + (j + 1) + "): ", scanner);
            }
        }
        return matrix;
    }

    private static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}