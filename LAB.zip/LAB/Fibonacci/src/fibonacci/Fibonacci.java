/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fibonacci;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Fibonacci {

   
    public static void main(String[] args) {
        boolean test = true;
        
        // Step 1. find 45 sequence Fibonacci
        int[] arr = find45SequenceFibonacci();
        
        // Step 2. display result
        displayResult(arr, test);
        
        Scanner sc = new Scanner(System.in);
        sc.nextLine();
    }

    private static int[] find45SequenceFibonacci() {
        int[] arr = new int[45];
        findFibonacciNumber(arr, 0);
        return arr;
    }

    // recursion until i = arr.length
    private static void findFibonacciNumber(int[] arr, int i) {
        // check if i = arr length
        if (i == arr.length ){
            return ;
        }
        
        // check if i < 2
        if (i < 2) {
            arr[i] = i;
        }
        else
        {
            arr[i] = arr[i-1] + arr[i-2];
        }
        
        findFibonacciNumber(arr, i+1);
    }

    private static void displayResult(int[] arr, boolean test) {
        System.out.println("The 45 sequence fibonacci: ");
        
        // loop to all elements in array
        for (int i = 0; i < arr.length; i++) {
            // check if test is false
            if (test == false){
                System.out.print( arr[i] );
                
                // check if i != arr.length -1 
                if (i != arr.length - 1){
                    System.out.print(", ");
                }
            }
            else{
                // check if i < 2
                if (i < 2){
                    System.out.println((1+i) + ". " + arr[i]);
                }
                else{
                    System.out.println((1+i) + ". " + arr[i] + " = " + arr[i-1] + " + " + arr[i-2]);
                }
                
            }
            
        }

    }
    
}
