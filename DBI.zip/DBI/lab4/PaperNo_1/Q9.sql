create trigger tr_delete_productInventory_location 
on ProductInventory
for delete
as 
begin 
	select
		deleted.ProductID,
		deleted.LocationID,
		Name as LocationName,
		Shelf,
		Bin,
		Quantity

	from
		deleted join Product on deleted.ProductID = Product.ProductID

end


