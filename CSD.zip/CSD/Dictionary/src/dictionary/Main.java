/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dictionary;

import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Main {

    public static void main(String[] args) {

        // endless loop
        do {

            //Step 1. load data from file
            HashMap<String, String> dictionary = Manager.loadData();

            //Step 2. display menu
            Manager.displayMenu();

            //Step 3. user enter choice
            int choice = DataValidation.enterChoice();
            
            //Step 4. perform chosen function
            Manager.performFunction(choice, dictionary);

        } while (true);
    }
    
    
    

   
}
