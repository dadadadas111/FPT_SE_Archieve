--8
use abc;
WITH TongSanPhamBan AS(
	SELECT 
		r1.MAVT,
		COALESCE(SUM(SL), 0) AS 'SL HoaDon'
	FROM
		SanPham r1
		LEFT JOIN
		ChiTietHoaDon r2
		ON r1.MaVT = r2.MaVT
	GROUP BY
		r1.MaVT
)

SELECT
	r1.MAVT,
	TENVT,
	DVT,
	GIAMUA,
	[SL HoaDon]
FROM
	TongSanPhamBan r1
	JOIN SanPham r2 ON r1.MaVT = r2.MaVT
WHERE
	[SL HoaDon] = (
		SELECT MIN( [SL HoaDon])
		FROM TongSanPhamBan
	)