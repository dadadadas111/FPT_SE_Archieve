package heaps;
public class Main {
    public static void main(String[] args) {
        //int a[]={2,8,6,1,10};
        int n=5;
        int a[]=new int[1];
        a[0]=2;
        ArrayHeap.makeHeap(a);
        ArrayHeap.printArray(a);

        a=new int[2];
        a[0]=2;a[1]=8;
        ArrayHeap.makeHeap(a);
        ArrayHeap.printArray(a);
        
        a=new int[3];
        a[0]=2;a[1]=8; a[2]=6;
        ArrayHeap.makeHeap(a);
        ArrayHeap.printArray(a);
        
        a=new int[4];
        a[0]=2;a[1]=8; a[2]=6; a[3]=1;
        ArrayHeap.makeHeap(a);
        ArrayHeap.printArray(a);

        a=new int[5];
        a[0]=2;a[1]=8; a[2]=6; a[3]=1; a[4]=10;
        ArrayHeap.makeHeap(a);
        ArrayHeap.printArray(a);
        
    }
}
