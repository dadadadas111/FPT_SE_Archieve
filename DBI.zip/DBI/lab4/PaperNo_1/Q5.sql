

SELECT    p.ProductID, p.Name, sum(quantity) as TotalQuantity
FROM         Location AS l INNER JOIN
                      ProductInventory AS pi ON l.LocationID = pi.LocationID INNER JOIN
                      Product AS p ON pi.ProductID = p.ProductID

GROUP BY
	p.ProductID, p.Name
HAVING sum(quantity) > 1700
ORDER BY
	TotalQuantity desc, Name asc

