
--2
SELECT *
FROM 
	KhachHang
WHERE
	DiaChi = 'TAN BINH';

--3
SELECT *
FROM
	SanPham
WHERE
	TenVT LIKE '%GACH%';

--4
SELECT HoaDon.MaHD, Ngay, TenKH, DiaChi, DT 
FROM
	HoaDon
	JOIN
	KhachHang
	ON HoaDon.MaKH = KhachHang.MaKH
ORDER BY
	Ngay;

--5
SELECT DISTINCT	
	MaKH, DiaChi, DT
FROM 
	KhachHang
WHERE
	MaKH NOT IN (
		SELECT MaKH 
		FROM HoaDon 
		WHERE Ngay BETWEEN '2000-06-01' AND '2000-06-30');
	
--6
SELECT
	MAHD,
	r1.MAVT,
	TENVT,
	DVT,
	GIABAN,
	GIAMUA,
	SL,
	(SL * GIAMUA) AS TriGiaMua,
	(SL * GIABAN) AS TriGiaBan

FROM
	ChiTietHoaDon r1 
	JOIN 
	SanPham r2
	ON r1.MaVT = r2.MaVT
WHERE 
	GIABAN >= GIAMUA;


--7
WITH TongHoaDon AS(
	SELECT
		MAHD,
		SUM(SL * GiaBan) AS TongGiaTri
	FROM
		ChiTietHoaDon
	GROUP BY
		MAHD
)

SELECT
	r1.MAHD,
	CAST(Ngay AS DATE)NGAY,
	r3.MAKH,
	TENKH,
	DIACHI,
	TongGiaTri
FROM
	TongHoaDon r1
	JOIN HoaDon r2 ON r1.MaHD = r2.MaHD
	JOIN KhachHang r3 ON r2.Makh = r3.MaKH
WHERE
	TongGiaTri = (
		SELECT TOP 1 TongGiaTri
		FROM TongHoaDon
		ORDER BY TongGiaTri DESC
	)


--8

WITH TongSanPhamBan AS(
	SELECT 
		r1.MAVT,
		COALESCE(SUM(SL), 0) AS 'SL HoaDon'
	FROM
		SanPham r1
		LEFT JOIN
		ChiTietHoaDon r2
		ON r1.MaVT = r2.MaVT
	GROUP BY
		r1.MaVT
)

SELECT
	r1.MAVT,
	TENVT,
	DVT,
	GIAMUA,
	COALESCE(r1.[SL HoaDon], 0) AS 'SL HoaDon'
FROM
	TongSanPhamBan r1
	RIGHT JOIN SanPham r2 ON r1.MaVT = r2.MaVT
WHERE
	[SL HoaDon] = (
		SELECT TOP 1 [SL HoaDon]
		FROM TongSanPhamBan
		ORDER BY [SL HoaDon]
	)