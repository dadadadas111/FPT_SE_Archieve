/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bstree;

/**
 *
 * @author asus
 */
public class Main {

    public static void main(String[] args) {
        BStree b = new BStree();
        Car[] car = new Car[10];
        int[] a = {1,3,5,2,7,4,9,8,6,0};
        for (int i = 0; i < car.length; i++) {
            String s = "";
            s += (char)('A' + i);
            car[i] = new Car( s , a[i]);
            
        }
        
        b.createTree(car);
        //System.out.println(b.root);

        b.postOrder(b.root);
        System.out.println("");
        b.inOrder(b.root);
        System.out.println("");
        b.preOrder(b.root);
        System.out.println("");
    }

}
