/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fibonacci;

/**
 *
 * @author asus
 */
public class Fibonacci {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("The 45 sequence fibonacci: ");
        fibonacciHelper( 45, 1, 0);
    }
    public static void fibonacciHelper(int term, int lower, int higher){
        //if term = 0 -> 45 sequences have been displayed. stop function
        if (term == 0 ) return;
        
        // higher will be printed 
        System.out.print(higher + " " );
        //fibonacci: F(n) = F(n-1) + F(n-2)
        // using recursion method
        fibonacciHelper( term-1, higher, lower + higher);
    }
}
