function showPrice(){
    let tour = document.getElementById('tour');
    let price = document.getElementById('price');
    price.innerText = tour.value + "$/person"
}

function CalTotal(){

    let input = document.querySelectorAll('input');
    input.forEach(element => {
        if (element.value.length == 0){
            return;
        }
    });

    let number = document.getElementById('number').value;
    let tour = document.getElementById('tour').value;
    let total = document.getElementById('total').querySelector('p');
    total.innerText = "Total Amount: " + (number * tour) + "$";
}