SELECT    Class.classCode , Class.className,
			count(StudentID) as NumberOfStudents
FROM         Class left JOIN
                      Student_Class ON Class.classCode = Student_Class.classCode

					  GROUP BY Class.classCode, Class.className
					  ORDER BY NumberOfStudents DESC