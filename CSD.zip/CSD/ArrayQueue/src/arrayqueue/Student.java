/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayqueue;

/**
 *
 * @author asus
 */
public class Student {

    private int studentId;

    private String name;

    private int age;

    public Student(int studentId, String name, int age) {

        this.studentId = studentId;

        this.name = name;

        this.age = age;

    }

// Getters and setters (if needed)
    public int getStudentId() {

        return studentId;

    }

    public String getName() {

        return name;

    }

    public int getAge() {

        return age;

    }

}
