package graph;
public class Node {
    Object infor;
    Node next;
    Node(){}
    Node(Object x){
        infor=x;
        next=null;
    }
    Node (Object x, Node p){
        infor=x;
        next=p;
    }
}
