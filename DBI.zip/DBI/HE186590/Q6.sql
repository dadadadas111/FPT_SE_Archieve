

WITH TotalEmps AS(

SELECT
	DepartmentName,
	COUNT(EmployeeID) AS [Total Employees] 
FROM
	Departments d
	LEFT JOIN Employees e ON d.DepartmentID = e.DepartmentID 
GROUP BY 
	d.DepartmentID,
	DepartmentName
)

SELECT *
FROM
	TotalEmps
WHERE
	[Total Employees] = (SELECT MIN([Total Employees]) FROM TotalEmps)
ORDER BY
	DepartmentName

	