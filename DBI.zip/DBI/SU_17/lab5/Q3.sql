SELECT    Student_Class.studentID, Student.studentFName, Student.studentLName, Class.classCode, className
FROM         Class INNER JOIN
                      Student_Class ON Class.classCode = Student_Class.classCode INNER JOIN
                      Student ON Student_Class.studentID = Student.studentID