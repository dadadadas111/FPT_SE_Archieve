package bubblesort;

import java.util.*;

public class BubbleSort {

    public static void main(String[] args) {
        //step 1. Enter size of the array
        int size = enterSizeOfArray();
        //step 2. Generate random array
        int[] arr = generateRandomArray(size);
        //step 3. Display the unsorted array
        display(arr, "Unsorted array: ");
        //step 4. Sort array by using bubble sort
        sortByBubbleSort(arr);
        //step 5. Display the sorted array
        display(arr, "Sorted array: ");
    }

    public static int enterSizeOfArray() {
        System.out.println("Enter the number of array: ");
        Scanner sc = new Scanner(System.in);
        int size;
        String input = sc.nextLine();
        try {
            size = Integer.parseInt(input);
            if (size <= 0) {
                throw new Exception();
            }
        } catch (Exception e) {
            System.out.println("Input must be a positive integer. Try again.");
            return enterSizeOfArray();
        }
        return size;
    }

    public static int[] generateRandomArray(int size) {
        int[] arr = new int[size];
        Random r = new Random();
        for (int i = 0; i < arr.length; i++) {
            arr[i] = r.nextInt(size + 1) % size;
        }
        return arr;
    }

    public static void display(int[] arr, String msg) {
        System.out.print(msg);
        System.out.print("[" + arr[0]);
        for (int i = 1; i < arr.length; i++) {
            System.out.print(", " + arr[i]);

        }
        System.out.println("]");
    }

    public static void sortByBubbleSort(int arr[]) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
}
