package btree;

public class Btree {

    Node root;

    public Btree() {
        root = new Node();
    }

    void breadth() {
        if (root == null) {
            return;
        }
        Queue q = new Queue();
        q.enqueue(root);
        Node p;
        while (!q.isEmpty()) {
            p = (Node) q.dequeue();
            if (p.left != null) {
                q.enqueue(p.left);
            }
            if (p.right != null) {
                q.enqueue(p.right);
            }
            visit(p);
        }
    }

    public void preOrder(Node p) {
        if (p == null) {
            return;
        }
        visit(p);
        preOrder(p.left);
        preOrder(p.right);
    }

    public void inOrder(Node p) {
        if (p == null) {
            return;
        }
        inOrder(p.left);
        visit(p);
        inOrder(p.right);
    }

    public void postOrder(Node p) {
        if (p == null) {
            return;
        }
        postOrder(p.left);
        postOrder(p.right);
        visit(p);
    }

    public void visit(Node p) {
        p.print();
    }

    public Node search(Node r, int x) {
        Node p = new Node();
        if (r == null) {
            return null;
        }
        if (r.info == x) {
            return r;
        }
        p = search(r.left, x);
        if (p != null) {
            return p;
        } else {
            p = search(r.right, x);
            return p;
        }
    }

    public void makeBtree(int n) {
        //1,2,...,n
        Node p = new Node();
        root = new Node(1);
        for (int i = 2; i <= n; i++) {
            int j = (i / 2);
            p = search(root, j);
            if (i == 2 * j) {
                p.left = new Node(i);
            } else {
                p.right = new Node(i);
            }
        }
    }
    public void makeBtree(int a[]) {
        root = makeNode(a, 1);
    }
    public Node makeNode( int[] a, int i){
        if(a.length < i) return null;
        Node p = new Node(a[i-1], makeNode(a, 2*i), makeNode(a, 2*i+1));
        return p;
    }
    public boolean isLeaf(Node p){
        return(p!=null && p.left==null && p.right==null);
    }
    public int countLeaf(Node r){
        int cnt=0;
        if (root == null) {
            return 0;
        }
        if(isLeaf(r))
            return cnt+1;
        if(r.left!=null)cnt+=countLeaf(r.left);
        if(r.right!=null) cnt+=countLeaf(r.right);
        return cnt;
    }
    public Node createBTree(int x, Node l, Node r){// x is root, l is left child, r is right child
        Node p = new Node(x);
        p.left = l;
        p.right = r;
        return p;
    }    
    public void makeBtree2(int a[]) {
        int n = a.length;
        int[] b = new int[n + 1];
        for (int i = 1; i <= n; i++) {
            b[i] = a[i - 1];
        }

        //1,2,...,n
        Node p = new Node();
        root = new Node(b[1]);
        for (int i = 2; i <= n; i++) {
            int j = (i / 2);
            p = search(root, b[j]);
            if (i == 2 * j) {
                p.left = new Node(b[i]);
            } else {
                p.right = new Node(b[i]);
            }
        }
    }
//    void creatBtree(){
//    //         0
//    //    1        9
//    //  8   3   10     2
//        root=new Node(0);
//        Node p=root;
//        p.left=new Node(1);
//        p.right=new Node(9);
//        p.left.left=new Node(8);
//        p.left.right=new Node(3);
//        p.right.left=new Node(10);
//        p.right.right=new Node(2);
//    }    

}

//    Node root;
//    public Btree() {
//
//    }
//    void breadth(){
//    }
//    public void preOrder(Node p){
//    }
//    public void inOrder(Node p){
//    }
//    public void postOrder(Node p){
//    }
//    public void visit(Node p){
//    }
//    void creatBtree(int a[]){
//    //         0
//    //    1        2
//    //  3   4   5     6
//    }   
