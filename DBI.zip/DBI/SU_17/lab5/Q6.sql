

with 
finalScore as(
SELECT t.studentID, e.examScore
FROM (
	SELECT    studentID, subjectCode,  MAX(examDate) as examDate
FROM         exam

					  group by studentID, subjectCode
					   ) t
					   JOIN
					   exam e
ON t.studentID = e.studentID AND e.examDate = t.examDate and e.subjectCode = t.subjectCode
				


					  

)

select 
	studentID, 
	SUM(examScore) / (SELECT COUNT (*) FROM Subject) as avgScore 
from
	finalScore
group by studentID

