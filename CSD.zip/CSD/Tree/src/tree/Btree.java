/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tree;

import java.util.*;

/**
 *
 * @author asus
 */
public class Btree {

    Node root;

    public Btree() {

    }

    public boolean isEmpty() {
        return root == null;
    }

    void breadth() {
        if (isEmpty()) {
            return;
        }
        Queue<Node> q = new LinkedList<Node>();
        q.offer(root);
        while (q.isEmpty() == false) {

            Node p = q.poll();
            visit(p);
            if (p.left != null) {
                q.offer(p.left);
            }
            if (p.right != null) {
                q.offer(p.right);
            }
        }

    }

    public void preOrder(Node p) {
        if (p == null) {
            return;
        }
        visit(p);
        preOrder(p.left);
        preOrder(p.right);

    }

    public void inOrder(Node p) {
        if (p == null) {
            return;
        }
        inOrder(p.left);
        visit(p);
        inOrder(p.right);

    }

    public void postOrder(Node p) {
        if (p == null) {
            return;
        }
        postOrder(p.left);
        postOrder(p.right);
        visit(p);

    }

    public void visit(Node p) {
        if (p == null) {
            return;
        }
        System.out.print(p.info + " -> ");
    }

    public void createBtree(int[] a) {
        root = generateTree(a, 1);

    }

    public Node generateTree(int[] a, int i) {
        if (i > a.length) {
            return null;
        }
        Node p = new Node(a[i - 1], generateTree(a, i * 2), generateTree(a, i * 2 + 1));
        return p;
    }

    public int level(int a[]) {
        int n = a.length,
                S = 0,
                k = 0;
        while (S < n) {
            S += Math.pow(2, k);
            k++;
        }
        return k;
    }

    public Node search(Node r, int x) {
        if (r == null) {
            return null;
        }
        if ((int) r.info == x) {
            return r;
        }
        Node p = null;
        p = search(r.left, x);
        if (p == null) {
            p = search(r.right, x);
        }
        return p;
    }
    
    public boolean isLeaf(Node p){      
        return ( p != null && p.left == null && p.right == null);
    }
    public int countLeaf(Node r){
        if (r == null) return 0;
        if (isLeaf(r)) return 1;  
        return countLeaf(r.left) + countLeaf(r.right);
    }
}
