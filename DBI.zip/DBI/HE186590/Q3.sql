

SELECT	
	EmployeeID,
	LastName,
	FirstName,
	JobTitle,
	Salary
FROM
	Employees e
	JOIN Jobs j ON e.JobID = j.JobID
WHERE 
	Salary BETWEEN 14000 AND 20000
