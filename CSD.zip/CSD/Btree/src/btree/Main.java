package btree;

public class Main {

    public static void main(String[] args) {
        int[] a = {20, 31, 84, 95, 16, 27, 83,1,2,3};
        Btree btr = new Btree();
        //btr.creatBtree();
        btr.makeBtree(a);
//        btr.makeBtree(10);
        System.out.println("Bread first search");
        btr.breadth();
        System.out.println();
        System.out.println(btr.countLeaf(btr.root));
        //System.out.println("Address: "+btr.search(btr.root, 3).info+" "+ btr.search(btr.root, 3).toString());

//        
//        System.out.println("Preorder");
//        btr.preOrder(btr.root);
//        System.out.println();
//        
//        System.out.println("Inorder");
//        btr.inOrder(btr.root);
//        System.out.println();
//        
//        System.out.println("Postorder");
//        btr.postOrder(btr.root);
//        System.out.println();
//        Btree btr=new Btree();
//        String str="0 1 2 3 4 5 6";
//        String[] a=str.split(" ");
//        int index[]={0};
//        Node root= btr.buildTreePreOrder(a, index);
//        btr.breadth();
//        System.out.println();
//        btr.inOrder(root);
//        System.out.println();
//        btr.preOrder(root);
//        System.out.println();
//        Btree b = new Btree();
//        b.makeBtree(a);
//        b.breadth();
    }

}
