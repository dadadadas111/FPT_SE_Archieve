/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computerprogram;

/**
 *
 * @author asus
 */
public class BMICalculator {
    int weight, height;
    double value;
    String status;

    public BMICalculator(int weight, int height) {
        value = 10000.0*weight/(height * height);
        
        // check if BMI is lower than 19
        if (value < 19){
            status = "UNDER-STANDARD";
        }
        // check if BMI is lower than 25
        else if (value < 25){
            status = "STANDARD";
        } 
        // check if BMI is lower than 30
        else if (value < 30){
                status = "OVERWEIGHT";
        }
        // check if BMI is lower than 50
        else if (value < 50){
            status = "FAT - SHOULD LOSE WEIGHT";
        }
        else {
            status = "VERY FAT - SHOULD LOSE WEIGHT";
        }
    }
    
    public static void process(){
        System.out.println("\n----- BMI Calculator -----");
        int weight = Validation.enterPositiveInt("Enter Weight(kg): ");
        int height = Validation.enterPositiveInt("Enter Height(cm): ");
        
        BMICalculator bmi = new BMICalculator(weight, height);
        
        System.out.printf("BMI Number: %.2f", bmi.value);
        System.out.println();
        System.out.println("BMI Status: " + bmi.status);
    }   
    
}
