use Lab3_1	;

-- 1
CREATE TABLE Employees (
	id char(10) primary key,
	name varchar(30),
	manager_id char(10) references Employees(id)
)


-- 2

CREATE TABLE Locations(
	Code char(10) primary key,
	Name varchar(10)
)

CREATE TABLE Flights (
	Flight# char(10) primary key,
	Flight_Date date,
	Flight_From char(10) references Locations(Code),
	Flight_To char(10) references Locations(Code)
)

-- 3

-- CREATE TABLE Employees (
--	id char(10) primary key,
--	name varchar(30)
--)

CREATE TABLE Products(
	Code char(10) primary key,
	Product_Name varchar(10),
	Employee_id char(10) references Employees(id)

)

-- 4

CREATE TABLE Products_2(
	Code char(10) primary key,
	Product_Name varchar(10),
	Price float,
)

CREATE TABLE Sale(
	Product_code char(10) references Products_2(Code) ,
	Employee_id char(10) references Employees(id),
	Sale_date date

)

-- 5

CREATE TABLE Customer(
	Customer_id char(10) primary key,
	Customer_name varchar(10) ,

)

CREATE TABLE Sale_2(
	Product_code char(10) references Products(Code),
	Employee_id char(10) references Employees(id),
	Customer_id char(10) references Customer(Customer_id),
	Quantity int,

)

-- 6

CREATE TABLE Person (
	Code char(10) primary key,
	_name varchar(10),
)

CREATE TABLE Teacher (
	Code char(10) references Person(Code),
	Speciality varchar(10)
)

CREATE TABLE Student(
	Code char(10) references Person(Code),
	Class varchar(5)
)
	


