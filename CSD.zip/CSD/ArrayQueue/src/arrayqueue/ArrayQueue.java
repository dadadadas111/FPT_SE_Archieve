/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayqueue;

/**
 *
 * @author asus
 */
public class ArrayQueue {

    int first, last, max;

    Object[] A;

    public ArrayQueue() {
        this(10);
    }

    public ArrayQueue(int size) {
        max = size;
        A = new Object[size];
        first = last = -1;
    }

    public boolean isEmpty() {
        return (first == -1);
    }

    public boolean isFull() {
        return ((first == 0 && last == max - 1) || first == last + 1);
    }

    private boolean grow() {
        int i, j;
        int max1 = max + max / 2;
        Object[] a1 = new Object[max1];
        if (a1 == null) {
            return false;
        }
        if (last >= first) {
            for (i = first; i <= last; i++) {
                a1[i - first] = A[i];
            }
        } else {
            for (i = first; i < max; i++) {
                a1[i - first] = A[i];
            }
            i = max - first;
            for (j = 0; j <= last; j++) {
                a1[i + j] = A[j];
            }
        }
        A = a1;
        first = 0;
        last = max - 1;
        max = max1;
        return true;
    }

    public Object dequeue() {
        if (isEmpty()) {
            return null;
        }
        Object x = A[first];
        if (first == last) {
            first = last = -1;
        } else {
            first = (first + 1) % max;
        }
        return x;
    }

    public void enqueue(Object x) {
        if (isFull() && !grow()) {
            System.out.println("Failed.");
            return;
        }
        if (isEmpty()) {
            first = last = 0;
            A[first] = x;
            return;
        }
        last = (last + 1) % max;
        A[last] = x;
    }

    public Object front() {
        if (isEmpty()) {
            System.out.println("Failed.");
            return null;
        }
        return A[first];
    }

    public void input(int n) {
        for (int i = 0; i < n; i++) {
            enqueue(i);
        }
    }

    public void output() {
        if (isEmpty()) {
            return;
        }
        if (first <= last) {
            for (int i = first; i <= last; i++) {
                System.out.print(" " + A[i]);

            }
        } else {
            for (int i = first; i < max; i++) {
                System.out.print(" " + A[i]);
            }
            for (int i = 0; i <= last; i++) {
                System.out.print(" " + A[i]);
            }
        }
    }

    public void delK(int k) {
        if (isEmpty() || k < 1 || k > size()) {
            return;
        }
        if (first == last) {
            first = last = -1;
            return;
        }
        int currentIndex = first;
        for (int i = 1; i < k; i++) {
            currentIndex = (currentIndex + 1) % max;
        }

        for (int i = k; i < size(); i++) {
            A[currentIndex] = A[(currentIndex + 1) % max];
            currentIndex = (currentIndex + 1) % max;
        }

        last = (last - 1 + max) % max;
    }

    public int size() {
        if (isEmpty()) {
            return 0;
        }
        if (first <= last) {
            return last - first + 1;
        } else {
            return max - first + last + 1;
        }
    }

}
