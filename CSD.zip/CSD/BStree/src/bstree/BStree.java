/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bstree;

/**
 *
 * @author asus
 */
public class BStree {

    Node root;

    public BStree() {
        root = null;
    }

    public boolean isEmpty() {
        return root == null;
    }

    public void clear() {
        root = null;
    }

    public boolean isLeaf(Node r) {
        return (r != null && r.left == null && r.right == null);
    }

    public Node search(Node p, int xKey) {
        if (p == null) {
            return null;
        }
        if (p.key == xKey) {
            return p;
        }
        if (p.key > xKey) {
            return search(p.left, xKey);
        }
        return search(p.right, xKey);
    }

    public void insert(Car c) {
        if (isEmpty()) {
            root = new Node(c);
            return;
        }
        
        if (search(root, c.price) != null ){
            return;
        }
        
        Node p = root;  
        while (p != null){
            if (p.key < c.price && p.right != null){
                p = p.right;
            }
            else if (p.key > c.price && p.left != null){
                p = p.left;
            }
            else break;
        }
        if (p.key < c.price){
            p.right = new Node(c);
        }
        else {
            p.left = new Node (c);
        }
       

    }
    
    public Node deleteByMerging(Node root, int key){
        if (root == null){
            return null;
        }
        if (key < root.key){
            root.left = deleteByMerging(root.left, key);
        }
        else if (key > root.key){
            root.right = deleteByMerging(root.right, key);
        }
        else {
            if (isLeaf(root)) return null;
            if (root.left == null) return root.right;
            if (root.right == null) return root.left;
//            Node leftMax = findMax(root.left);
//            leftMax.right = root.right;
//            root = root.left;
              Node rightMin = findMin(root.right);
              rightMin.left = root.left;
              root = root.right;
            
        }
        return root;
    }
    
    public Node deleteByCopying(Node root, int key){
        if (root == null){
            return null;
        }
        if (key < root.key){
            root.left = deleteByCopying(root.left, key);
        }
        else if (key > root.key){
            root.right = deleteByCopying(root.right, key);
        }
        else {
            if (isLeaf(root)) return null;
            if (root.left == null) return root.right;
            if (root.right == null) return root.left;
            Node leftMax = findMax(root.left);
            root.key = key;
            root.info = leftMax.info;
            root.left = deleteByCopying(root.left, leftMax.key);
           
        }
        return root;
    }
    

    public void createTree(Car a[]) {
        for (Car car : a) {
            insert(car);
        }
    }
    
    public void createAVLTree (Car a[], int left, int right){
        if (left > right) return;
        int mid = (left + right) / 2;
        insert(a[mid]);
        createAVLTree(a, left, mid-1);
        createAVLTree(a, mid+1, right);
    }
    

    public Node createBTree(Car x, Node l, Node r) {
        return new Node(x, l, r);
    }

//    public Node createBSTree(Car x, Node l, Node r) {
//        
//    }

    public Node findMin(Node r) {
        if (r == null) return null;
        if (r.left != null) {
            return findMin(r.left);
        }
        else return r;
    }

    public Node findMax(Node r) {
        if (r == null) return null;
        if (r.right != null) {
            return findMax(r.right);
        }
        else return r;
    }

    public void preOrder(Node r) {
        if (r == null) {
            return;
        }
        visit(r);
        preOrder(r.left);
        preOrder(r.right);
        
    }

    public void inOrder(Node r) {
        if (r == null) {
            return;
        }
        inOrder(r.left);
        visit(r);
        inOrder(r.right);

    }

    public void postOrder(Node r) {
        if (r == null) {
            return;
        }
        postOrder(r.left);
        postOrder(r.right);
        visit(r);
    }

    public void visit(Node p) {
        if (p == null) {
            return;
        }
        p.printKey();
    }
    
    public Node rotateRight(Node y){
        Node x = y.left;
        Node T2 = x.right;

        // Perform rotation
        x.right = y;
        y.left = T2;
        return x;
    }

}
