/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedstack;

/**
 *
 * @author asus
 */
public class MinStack {
    Stack mainStack;
    Stack minStack;

    public MinStack() {
        mainStack = new Stack();
        minStack = new Stack();
    }

    public void push(int x) {
        mainStack.push(x);

        if (minStack.isEmpty() || x <= (int)minStack.peek()) {
            minStack.push(x);
        }
    }

    public void pop() {
        if (!mainStack.isEmpty()) {
            int poppedElement = (int)mainStack.pop();
            if (!minStack.isEmpty() && poppedElement == (int)minStack.peek()) {
                minStack.pop();
            }
        }
    }

    public Object top() {
        if (!mainStack.isEmpty()) {
            return (int)mainStack.peek();
        }
        System.out.println("empty stack.");
        return null;
    }

    public Object getMin() {
        if (!minStack.isEmpty()) {
            return (int)minStack.peek();
        }
        System.out.println("empty stack.");
        return null;
    }
}