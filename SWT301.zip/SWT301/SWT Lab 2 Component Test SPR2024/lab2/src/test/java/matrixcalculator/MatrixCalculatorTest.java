/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package matrixcalculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 *
 * @author asus
 */
public class MatrixCalculatorTest {
    
    public MatrixCalculatorTest() {
    }

   
    /**
     * Test of addMatrices method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 2, 3, 4, 5, 6, 7, 8",
        "9, 10, 11, 12, 13, 14, 15, 16",
        "17, 18, 19, 20, 21, 22, 23, 24"
    })
    public void testAddMatrices(int a, int b, int c, int d, int e, int f, int g, int h) {
        System.out.println("addMatrices (success test case)");
        int[][] matrix1 = {{a, b}, {c, d}};
        int[][] matrix2 = {{e, f}, {g, h}}; 
        MatrixCalculator instance = new MatrixCalculator();
        int[][] expResult = {{a + e, b + f}, {c + g, d + h}};
        int[][] result = instance.addMatrices(matrix1, matrix2);
        assertArrayEquals(expResult, result);
    }

    @ParameterizedTest
    @CsvSource({
        // format row matrix1, column matrix1, row matrix2, column matrix2
        "2, 2, 3, 2",
        "2, 2, 2, 3",
        "2, 2, 3, 3"
    })
    public void testAddMatricesFailure(int a, int b, int c, int d) {
        System.out.println("addMatrices (failure test case)");
        // matrix1 and matrix2 have different dimensions
        int[][] matrix1 = new int[a][b];
        int[][] matrix2 = new int[c][d];
        // add value
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < b; j++) {
                matrix1[i][j] = 1;
            }
        }
        for (int i = 0; i < c; i++) {
            for (int j = 0; j < d; j++) {
                matrix2[i][j] = 1;
            }
        }
        MatrixCalculator instance = new MatrixCalculator();
        assertThrows(IllegalArgumentException.class, () -> {
            instance.addMatrices(matrix1, matrix2);
        });
    }

    /**
     * Test of subtractMatrices method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 2, 3, 4, 5, 6, 7, 8",
        "9, 10, 11, 12, 13, 14, 15, 16",
        "17, 18, 19, 20, 21, 22, 23, 24"
    })
    public void testSubtractMatrices(int a, int b, int c, int d, int e, int f, int g, int h) {
        System.out.println("subtractMatrices (success test case)");
        int[][] matrix1 = {{a, b}, {c, d}};
        int[][] matrix2 = {{e, f}, {g, h}}; 
        MatrixCalculator instance = new MatrixCalculator();
        int[][] expResult = {{a - e, b - f}, {c - g, d - h}};
        int[][] result = instance.subtractMatrices(matrix1, matrix2);
        assertArrayEquals(expResult, result);
    }

    @ParameterizedTest
    @CsvSource({
        // format row matrix1, column matrix1, row matrix2, column matrix2
        "2, 2, 3, 2",
        "2, 2, 2, 3",
        "2, 2, 3, 3"
    })
    public void testSubtractMatricesFailure(int a, int b, int c, int d) {
        System.out.println("subtractMatrices (failure test case)");
        // matrix1 and matrix2 have different dimensions
        int[][] matrix1 = new int[a][b];
        int[][] matrix2 = new int[c][d];
        // add value
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < b; j++) {
                matrix1[i][j] = 1;
            }
        }
        for (int i = 0; i < c; i++) {
            for (int j = 0; j < d; j++) {
                matrix2[i][j] = 1;
            }
        }
        MatrixCalculator instance = new MatrixCalculator();
        assertThrows(IllegalArgumentException.class, () -> {
            instance.subtractMatrices(matrix1, matrix2);
        });
    }

    /**
     * Test of multiplyMatrices method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12",
        "13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24",
        "25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36"
    })
    public void testMultiplyMatrices(int a, int b, int c, int d, int e, int f, int g, int h, int i, int j, int k, int l) {
        System.out.println("multiplyMatrices (success test case)");
        int[][] matrix1 = {{a, b, c}, {d, e, f}};
        int[][] matrix2 = {{g, h}, {i, j}, {k, l}};
        MatrixCalculator instance = new MatrixCalculator();
        int[][] expResult = {{a * g + b * i + c * k, a * h + b * j + c * l}, {d * g + e * i + f * k, d * h + e * j + f * l}};
        int[][] result = instance.multiplyMatrices(matrix1, matrix2);
        assertArrayEquals(expResult, result);
    }

    @Test
    public void testMultiplyMatricesFailure() {
        System.out.println("multiplyMatrices (failure test case)");
        // matrix1 and matrix2 have incompatible dimensions
        int[][] matrix1 = {{1, 2, 3}, {4, 5, 6}};
        int[][] matrix2 = {{7, 8}, {9, 10}};
        MatrixCalculator instance = new MatrixCalculator();
        assertThrows(IllegalArgumentException.class, () -> {
            instance.multiplyMatrices(matrix1, matrix2);
        });
    }

    /**
     * Test of transposeMatrix method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 2, 3, 4, 5, 6, 7, 8, 9",
        "10, 11, 12, 13, 14, 15, 16, 17, 18",
        "19, 20, 21, 22, 23, 24, 25, 26, 27"
    })
    public void testTransposeMatrix(int a, int b, int c, int d, int e, int f, int g, int h, int i) {
        System.out.println("transposeMatrix (success test case)");
        int[][] matrix = {{a, b, c}, {d, e, f}, {g, h, i}};
        MatrixCalculator instance = new MatrixCalculator();
        int[][] expResult = {{a, d, g}, {b, e, h}, {c, f, i}};
        int[][] result = instance.transposeMatrix(matrix);
        assertArrayEquals(expResult, result);
    }

    @Test
    public void testTransposeMatrixNotSquare() {
        System.out.println("transposeMatrix (not square test case)");
        // matrix is not square
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}};
        MatrixCalculator instance = new MatrixCalculator();
        int[][] expResult = {{1,4},{2,5},{3,6}};
        int[][] result = instance.transposeMatrix(matrix);
        assertArrayEquals(expResult, result);
    }

    /**
     * Test of scalarMultiplication method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 2, 3, 4, 5, 6",
        "7, 8, 9, 10, 11, 12",
        "13, 14, 15, 16, 17, 18"
    })
    public void testScalarMultiplication(int a, int b, int c, int d, int e, int f) {
        System.out.println("scalarMultiplication (success test case)");
        int[][] matrix = {{a, b, c}, {d, e, f}};
        int scalar = 2;
        MatrixCalculator instance = new MatrixCalculator();
        int[][] expResult = {{a * scalar, b * scalar, c * scalar}, {d * scalar, e * scalar, f * scalar}};
        int[][] result = instance.scalarMultiplication(matrix, scalar);
        assertArrayEquals(expResult, result);
    }

    /**
     * Test of powerOfMatrix method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 2, 3, 4, 5, 6, 7, 8, 9, 2",
        "10, 11, 12, 13, 14, 15, 16, 17, 18, 1",
        "19, 20, 21, 22, 23, 24, 25, 26, 27, -1"
    })
    public void testPowerOfMatrix(int a, int b, int c, int d, int e, int f, int g, int h, int i, int power) {
        System.out.println("powerOfMatrix");
        int[][] matrix = {{a, b, c}, {d, e, f}, {g, h, i}};
        MatrixCalculator instance = new MatrixCalculator();
        if (power < 0){
            assertThrows(IllegalArgumentException.class, () -> {
                instance.powerOfMatrix(matrix, power);
            });
        }
        int[][] expResult = matrix;
        for (int j = 1; j < power; j++) {
            expResult = instance.multiplyMatrices(expResult, matrix);
        }
        int[][] result = instance.powerOfMatrix(matrix, power);
        assertArrayEquals(expResult, result);
    }

    @Test
    public void testPowerOfMatrixFailure() {
        System.out.println("powerOfMatrix (failure test case)");
        // matrix is not square
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}};
        int power = 2;
        MatrixCalculator instance = new MatrixCalculator();
        assertThrows(IllegalArgumentException.class, () -> {
            instance.powerOfMatrix(matrix, power);
        });
    }


    /**
     * Test of determinant method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 2, 3, 4, 5, 6, 7, 8, 9",
        "1, 3, 5, 7, 9, 2, 4, 6, 8",
    })
    public void testDeterminant(int a, int b, int c, int d, int e, int f, int g, int h, int i) {
        System.out.println("determinant (success test case)");
        int[][] matrix = {{a, b, c}, {d, e, f}, {g, h, i}};
        MatrixCalculator instance = new MatrixCalculator();
        int expResult = a * e * i + b * f * g + c * d * h - c * e * g - b * d * i - a * f * h;
        int result = instance.determinantOfMatrix(matrix);
        assertEquals(expResult, result);
    }

    @Test
    public void testDeterminantFailure() {
        System.out.println("determinant (failure test case)");
        // matrix is not square
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}};
        MatrixCalculator instance = new MatrixCalculator();
        assertThrows(IllegalArgumentException.class, () -> {
            instance.determinantOfMatrix(matrix);
        });
    }

    /**
     * Test of isSymmetric method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 2, 3, 2, 4, 5, 3, 5, 6, true",
        "1, 2, 3, 4, 5, 6, 7, 8, 9, false"
    })
    public void testIsSymmetric(int a, int b, int c, int d, int e, int f, int g, int h, int i, boolean expResult) {
        System.out.println("isSymmetric (success test case)");
        int[][] matrix = {{a, b, c}, {d, e, f}, {g, h, i}};
        MatrixCalculator instance = new MatrixCalculator();
        boolean result = instance.isSymmetric(matrix);
        assertEquals(expResult, result);
    }

    @Test
    public void testIsSymmetricFailure() {
        System.out.println("isSymmetric (failure test case)");
        // matrix is not square
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}};
        MatrixCalculator instance = new MatrixCalculator();
        assertThrows(IllegalArgumentException.class, () -> {
            instance.isSymmetric(matrix);
        });
    }

    /**
     * Test of isDiagonal method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 0, 0, 0, 2, 0, 0, 0, 3, true",
        "1, 2, 0, 0, 1, 2, 0, 0, 1, false"
    })
    public void testIsDiagonal(int a, int b, int c, int d, int e, int f, int g, int h, int i, boolean expResult) {
        System.out.println("isDiagonal (success test case)");
        int[][] matrix = {{a, b, c}, {d, e, f}, {g, h, i}};
        MatrixCalculator instance = new MatrixCalculator();
        boolean result = instance.isDiagonal(matrix);
        assertEquals(expResult, result);
    }

    @Test
    public void testIsDiagonalFailure() {
        System.out.println("isDiagonal (failure test case)");
        // matrix is not square
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}};
        MatrixCalculator instance = new MatrixCalculator();
        assertThrows(IllegalArgumentException.class, () -> {
            instance.isDiagonal(matrix);
        });
    }

    /**
     * Test of isIdentity method, of class MatrixCalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "1, 0, 0, 0, 1, 0, 0, 0, 1, true",
        "1, 2, 0, 0, 1, 2, 0, 0, 1, false",
        "1, 0, 0, 0, 1, 0, 0, 0, 0, false"
    })
    public void testIsIdentity(int a, int b, int c, int d, int e, int f, int g, int h, int i, boolean expResult) {
        System.out.println("isIdentity (success test case)");
        int[][] matrix = {{a, b, c}, {d, e, f}, {g, h, i}};
        MatrixCalculator instance = new MatrixCalculator();
        boolean result = instance.isIdentity(matrix);
        assertEquals(expResult, result);
    }

    @Test
    public void testIsIdentityFailure() {
        System.out.println("isIdentity (failure test case)");
        // matrix is not square
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}};
        MatrixCalculator instance = new MatrixCalculator();
        assertThrows(IllegalArgumentException.class, () -> {
            instance.isIdentity(matrix);
        });
    }
}
