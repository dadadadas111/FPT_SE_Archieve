
SELECT    LocationID, Name, CostRate, Availability
FROM         Location
WHERE     (CostRate > 0)