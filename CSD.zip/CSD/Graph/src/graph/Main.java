package graph;
public class Main {
    public static void main(String[] args) {
        Graph g = new Graph();
        try{
//            System.out.println("\nDepth firs search");
//            g.depth(0);
//            System.out.println("\nBreadth first search");
//            g.breadth(0);
//            System.out.println("\nDijkstra algorithm and shortest path");
//            g.inputWeightedGraph();
//            g.displayMatrix(g.a);
//            g.shortestPath(0, 5);
//            g.shortestPath(0);
//            
//            g.floyd();
            
            g.inputEulerGraph();
            System.out.println("");
            System.out.println(g.countConnected(1));
//            g.eulerCycle();
          
            g.inputHamilton();
//            g.displayHamiltonCycle();
            System.out.println("---End---\n");


//              g.v = "ABCDEFGHI".toCharArray();
//              g.a = new int[9][];
//              g.a[0] = new int[] {0   ,0  ,0  ,0  ,1000,0  ,0  ,0  ,0  };
//              g.a[1] = new int[] {0   ,0  ,0  ,800,0   ,0  ,0  ,0  ,0};
//              g.a[2] = new int[] {0   ,0  ,0  ,0  ,0   ,0  ,250,300,280};
//              g.a[3] = new int[] {0   ,800,0  ,0  ,90  ,130,250,0  ,0};
//              g.a[4] = new int[] {1000,0  ,0  ,90 ,0   ,0  ,150,90 ,0};
//              g.a[5] = new int[] {0   ,0  ,0  ,130,0   ,0  ,120,0  ,80};
//              g.a[6] = new int[] {0   ,0  ,250,250,150 ,120,0  ,100,110};
//              g.a[7] = new int[] {0   ,0  ,300,0  ,90  ,0  ,100,0  ,0};
//              g.a[8] = new int[] {0   ,0  ,280,0  ,0   ,80 ,110,0  ,0};
//              
//              g.displayMatrix(g.a);
//              g.shortestPath(0, 2);
//              g.shortestPath(1, 2);
              

        }
        catch(Exception e){
            System.out.println("Err:"+e.getMessage());
        }
        
    }
    
}
