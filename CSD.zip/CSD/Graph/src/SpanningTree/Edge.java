package SpanningTree;
public class Edge {
    int head;
    int tail;
    int weight;
    public Edge(int head, int tail, int weight) {
        this.head = head;
        this.tail = tail;
        this.weight = weight;
    }    
}
