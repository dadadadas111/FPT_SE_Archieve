SELECT    Student.studentID, Student.studentFName, Student.studentLName, Student.studentGender, Student.studentDOB, Student.studentAddress
FROM         Scholarship INNER JOIN
                      Student_Scholarship ON Scholarship.schoName = Student_Scholarship.schoName RIGHT OUTER JOIN
                      Student ON Student_Scholarship.StudentID = Student.studentID

WHERE
	Scholarship.schoName is NULL