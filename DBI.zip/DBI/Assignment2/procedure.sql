CREATE PROC calculate_total_amount_cinema
@cinema_id INT, @total DECIMAL(10,2) OUTPUT
AS
BEGIN
	SET @total = (
		SELECT
			SUM(T.price)
		FROM
			Rooms R JOIN
			Showtimes S ON R.Room_id = S.Room_id JOIN
			Tickets T ON T.showtime_id = S.showtime_id JOIN
			OrderDetails OD ON T.ticket_id = OD.ticket_id
		WHERE 
			R.cinema_id = @cinema_id
	
	)


END



-- test

DECLARE @x DECIMAL(10, 2)

EXEC calculate_total_amount_cinema 1, @x OUTPUT

select @x

EXEC calculate_total_amount_cinema 2, @x OUTPUT

select @x