insert into Class ( classCode, className)
Values ('Class1000', 'New Class')

insert into Student(StudentID, studentFName, studentLName , studentGender, studentDOB, studentAddress)
Values ('ST1000', 'New', 'Student', 0, '1992-04-18', 'FU Hoa Lac')

declare @ID varchar(10) = (select top 1 studentID from Student where studentLName = 'Student')

insert into Student_Class( studentID, classCode)
Values (@ID, 'Class1000')

