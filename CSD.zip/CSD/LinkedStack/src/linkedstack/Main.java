/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedstack;

/**
 *
 * @author asus
 */
public class Main {

    public static void main(String[] args) {
        Stack stack = new Stack();
//        String s ="((({[{}]})))()(";
//        System.out.println(stack.checkParentheses(s));
        try {
            System.out.println(stack.evaluatePostfix("3 * 2 + 5 "));
        } catch (Exception e) {
        }
        
    }
}
