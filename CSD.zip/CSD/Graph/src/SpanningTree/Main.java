package SpanningTree;

/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {
        SpanningTree se=new SpanningTree(6,11);
//        System.out.println("Kruskal: ");
//        se.inputKruskal();
//        se.kruskal();
//        System.out.println("Prim: ");
        se.iputPrim();
        se.prim(3);
        
    }
}
