/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dictionary;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class DataValidation {

    public static int enterChoice() {
        Scanner sc = new Scanner(System.in);
        int choice = 0;

        // loop if choice is not in range [1, 4]
        while (choice < 1 || choice > 4) {
            System.out.print("Enter choice: ");
            try {
                choice = Integer.parseInt(sc.nextLine());
                // check if choice is not in range [1, 4]
                if (choice < 1 || choice > 4) {
                    throw new Exception();
                }

            } catch (Exception e) {
                System.out.println("Invalid choice. Try again.");
            }
        }
        return choice;
    }
}
