

SELECT
	EmployeeID,
	LastName,
	FirstName,
	City,
	CountryName,
	RegionName
FROM
	Employees e
	JOIN Departments d ON e.DepartmentID = d.DepartmentID
	JOIN Locations l ON d.LocationID = l.LocationID
	JOIN Countries c ON l.CountryID = c.CountryID
	JOIN Regions r ON r.RegionID = c.RegionID
WHERE 
	EmployeeID < 150
	AND
	RegionName = 'Europe'
ORDER BY
	LastName
