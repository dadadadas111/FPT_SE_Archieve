--2
use abc;

SELECT DISTINCT 
	KhachHang.MAKH,
	TENKH,
	DIACHI,
	DT,
	EMAIL

FROM 
	KhachHang
	JOIN
	HoaDon 
	ON KhachHang.MaKH = HoaDon.Makh
WHERE
	DiaChi = 'TAN BINH';
