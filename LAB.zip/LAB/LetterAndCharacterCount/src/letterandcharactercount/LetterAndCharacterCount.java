/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letterandcharactercount;

import com.sun.xml.internal.ws.util.StringUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.TreeMap;

/**
 *
 * @author asus
 */
public class LetterAndCharacterCount {

    public static void main(String[] args) {
        // Step 1: User enter content
        String input = enterContent();

        // Step 2: Display words 
        displayWords(input);

        // Step 3: Display characters  
        displayChars(input);
    }

    private static String enterContent() {
        Scanner sc = new Scanner(System.in);
        String input = "";
        // loop if input is empty
        while (input.isEmpty()) {
            System.out.println("Enter your content: ");
            input = sc.nextLine();
            // check if input is empty
            if (input.isEmpty()) {
                System.out.println("Content cannot be empty. Try again");
            }
        }
        return input;
    }

    private static void displayWords(String input) {
        StringTokenizer words = new StringTokenizer(input);

        HashMap<String, Integer> wordCount = new HashMap();

        // loop while words has more token
        while (words.hasMoreTokens()) {
            String s = words.nextToken();
            // check if s is in WordCount
            if (wordCount.containsKey(s)) {
                int count = wordCount.get(s);
                wordCount.put(s, count + 1);
            } else {
                wordCount.put(s, 1);
            }

        }
        String output = "";

        // loop to all entries in wordCount
        for (Map.Entry<String, Integer> e : wordCount.entrySet()) {
            output += " " + e.getKey() + "=" + e.getValue() + ",";

        }
        output = "{" + output.substring(1, output.length() - 1) + "}";

        System.out.println(output);
    }

    private static void displayChars(String input) {
        TreeMap<Character, Integer> charCount = new TreeMap();

        // loop to all character in input
        for (char c : input.toCharArray()) {
            // check if c is space characters
            if (Character.isWhitespace(c)) {
                continue;
            }
            // check if charCount contain c
            if (charCount.containsKey(c)) {
                int count = charCount.get(c);
                charCount.put(c, count + 1);
            } else {
                charCount.put(c, 1);
            }
        }

        String output = "";

        // loop to all entries in wordCount
        for (Map.Entry<Character, Integer> e : charCount.entrySet()) {
            output += " " + e.getKey() + "=" + e.getValue() + ",";

        }
        output = "{" + output.substring(1, output.length() - 1) + "}";

        System.out.println(output);

    }

}
