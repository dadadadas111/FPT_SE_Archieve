create trigger _NoMoreTwoScho 
on [Student_Scholarship]
for insert
as
begin
	declare @new_id varchar(10) = (SELECT inserted.StudentID FROM inserted )
	if
		(select count(*) from Student_Scholarship where StudentID = @new_id) > 2
	begin
		
		rollback transaction
		end

end

insert into Student_Scholarship
values ('ST02', 'Talent')

