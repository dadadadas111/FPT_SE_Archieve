/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayqueue;

import java.util.HashSet;
import java.util.Random;

/**
 *
 * @author asus
 */
public class LinkedQueue {

    Node head, tail;

    public LinkedQueue() {
        head = tail = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void clear() {
        head = tail = null;
    }

    public void enqueue(Object x) {
        if (isEmpty()) {
            head = tail = new Node(x, null);
            return;
        }
        tail.next = tail = new Node(x, null);

    }

    public Object front() {
        if (isEmpty()) {
            return null;
        }
        return head.info;
    }

    public Object dequeue() {
        if (isEmpty()) {
            return null;
        }
        if (length() == 1) {
            tail = null;
        }
        Object x = head.info;
        head = head.next;
        return x;
    }

    public int length() {
        int size = 0;
        Node p = head;
        while (p != null) {
            p = p.next;
            size++;
        }
        return size;
    }

    public void input(int n) {
        for (int i = 0; i < n; i++) {
            enqueue(i);
        }
    }
    public void inputRandom(int n){
        for (int i = 0; i < n; i++) {
            enqueue((new Random()).nextInt(100));
        }
    }

    public void output() {
        while (!isEmpty()) {
            System.out.print(dequeue() + " ");
        }
    }

    public void print() {
        if (isEmpty()) {
            return;
        }
        Node p = head;
        while (p != null) {
            System.out.print(p.info + " ");
            p = p.next;
        }
    }

    public Node get(int k) {
        if (k < 1 || k > length()) {
            return null;
        }
        Node p = head;
        for (int i = 0; i < k - 1; i++) {
            p = p.next;
        }
        return p;
    }

    public Node getPrev(int k) {
        return get(k - 1);
    }

    public Node delK(int k) {
        if (isEmpty()) {
            return null;
        }
        if (k == 1) {
            Node x = head;
            head = head.next;
            return x;
        }
        Node p = getPrev(k);
        if (p == null) {
            return null;
        }
        Node x = p.next;
        p.next = p.next.next;
        return x;
    }

    public void insertFirst(Object x) {
        if (isEmpty()) {
            head = tail = new Node(x, null);
            return;
        }
        head = new Node(x, head);
    }

    public Object removeLast() {
        return delK(length());
//        if (isEmpty()) {
//            return null;
//        }
//        Object x = tail.info;
//        tail = get(length()-1);
//        if (tail == null) head = null;
//        return x;
    }

    public void insertk(Object x, int k) {
        if (k < 1 || k > length() + 1) {
            return;
        }
        if (k == 1) {
            insertFirst(x);
            return;
        }
        if (k == length() - 1) {
            enqueue(x);
            return;
        }
        Node p = new Node(x, get(k));
        get(k-1).next = p;
        
    }
    public void swap(int i, int j){
        Node a = get(i);
        Node b = get(j);
        Object info = a.info;
        a.setInfo(b.info);
        b.setInfo(info);
        
    }
    
    public void sortInRange(int start, int end){
        if (get(start) == null || get(end) == null){
            System.out.println("fail");
            return;
        }
        for (int i = start; i < end; i++) {
            int min_pos = i;
            for (int j = i+1 ; j <= end; j++) {
                if ((int)get(j).info < ((int)get(min_pos).info) ){
                    min_pos = j;
                }
            }
            swap(i, min_pos);
            
        }
    }
}
