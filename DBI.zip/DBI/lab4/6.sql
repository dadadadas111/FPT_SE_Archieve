--6
use abc;

SELECT
	MAHD,
	r1.MAVT,
	TENVT,
	DVT,
	GIABAN,
	GIAMUA,
	SL,
	(SL * GIAMUA) AS TriGiaMua,
	(SL * GIABAN) AS TriGiaBan

FROM
	ChiTietHoaDon r1 
	JOIN 
	SanPham r2
	ON r1.MaVT = r2.MaVT
WHERE 
	GIABAN >= GIAMUA;