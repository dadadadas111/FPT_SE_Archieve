/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package bmicalculator;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 *
 * @author asus
 */
public class BMICalculatorTest {
    
    public BMICalculatorTest() {
    }

    /**
     * Test of calculateBMI method, of class BMICalculator.
     */
    @ParameterizedTest
    @CsvSource({
        "50, 1.5, 22.22",
        "60, 1.6, 23.44",
        "70, 1.7, 24.22",
        "80, 1.8, 24.69",
        "90, 1.9, 24.93",
        "100, 2.0, 25.00",
        "110, 2.1, 24.94",
        "120, 2.2, 24.79",
    })
    public void testCalculateBMI(double weight, double height, double expResult) {
        System.out.println("calculateBMI");
        BMICalculator instance = new BMICalculator(weight, height);
        instance.setWeight(weight);
        instance.setHeight(height);
        double result = instance.calculateBMI();
        assertEquals(expResult, result, 0.01);

    }

    /**
     * Test of getBMICategory method, of class BMICalculator.
     */
    @ParameterizedTest
    @CsvSource({
        // data from underweight, normal, overweight, obese
        "30, 1.5, Underweight",
        "60, 1.6, Normal",
        "80, 1.7, Overweight",
        "120, 1.8, Obese"
    })
    public void testGetBMICategory(double weight, double height, String expResult) {
        System.out.println("getBMICategory");
        BMICalculator instance = new BMICalculator(weight, height);
        instance.setWeight(weight);
        instance.setHeight(height);
        String result = instance.getBMICategory();
        assertEquals(expResult, result);
    }

    /**
     * Test of calculateIdealWeight method, of class BMICalculator.
     */
    @Test
    public void testCalculateIdealWeight() {
        System.out.println("calculateIdealWeight");
        BMICalculator instance = null;
        double expResult = 0.0;
        double result = instance.calculateIdealWeight();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateWeightDifference method, of class BMICalculator.
     */
    @Test
    public void testCalculateWeightDifference() {
        System.out.println("calculateWeightDifference");
        BMICalculator instance = null;
        double expResult = 0.0;
        double result = instance.calculateWeightDifference();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of convertWeightToPounds method, of class BMICalculator.
     */
    @Test
    public void testConvertWeightToPounds() {
        System.out.println("convertWeightToPounds");
        BMICalculator instance = null;
        double expResult = 0.0;
        double result = instance.convertWeightToPounds();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of convertHeightToInches method, of class BMICalculator.
     */
    @Test
    public void testConvertHeightToInches() {
        System.out.println("convertHeightToInches");
        BMICalculator instance = null;
        double expResult = 0.0;
        double result = instance.convertHeightToInches();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of convertHeightToFeet method, of class BMICalculator.
     */
    @Test
    public void testConvertHeightToFeet() {
        System.out.println("convertHeightToFeet");
        BMICalculator instance = null;
        double expResult = 0.0;
        double result = instance.convertHeightToFeet();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showMenu method, of class BMICalculator.
     */
    @Test
    public void testShowMenu() {
        System.out.println("showMenu");
        BMICalculator instance = null;
        instance.showMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of processMenu method, of class BMICalculator.
     */
    @Test
    public void testProcessMenu() {
        System.out.println("processMenu");
        int choice = 0;
        BMICalculator instance = null;
        instance.processMenu(choice);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setWeight method, of class BMICalculator.
     */
    @Test
    public void testSetWeight() {
        System.out.println("setWeight");
        double weight = 0.0;
        BMICalculator instance = null;
        instance.setWeight(weight);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setHeight method, of class BMICalculator.
     */
    @Test
    public void testSetHeight() {
        System.out.println("setHeight");
        double height = 0.0;
        BMICalculator instance = null;
        instance.setHeight(height);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of inputInfo method, of class BMICalculator.
     */
    @Test
    public void testInputInfo() {
        System.out.println("inputInfo");
//        BMICalculator.inputInfo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getChoice method, of class BMICalculator.
     */
    @Test
    public void testGetChoice() {
        System.out.println("getChoice");
//        BMICalculator.getChoice();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
