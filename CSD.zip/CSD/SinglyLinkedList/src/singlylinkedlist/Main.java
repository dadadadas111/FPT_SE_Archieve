/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singlylinkedlist;
import java.util.*;
/**
 *
 * @author asus
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SingleLinkedList myList = new SingleLinkedList();
        myList.addLast(1);
        myList.addLast(2);
        myList.addLast(3);
        myList.addLast(3);
        myList.addLast(4);
        myList.addLast(4);
        myList.addLast(5);
        myList.addLast(5);
        myList.addLast(6);
        myList.addLast(7);
        myList.addLast(7);
        myList.show();
        myList.insert(myList.head, 4);
        myList.show();
        System.out.println(myList.find(4));
        myList.findAll(3);
    }
    

}
// tinh do dai danh sach
// addLast neu linked list khong co tail