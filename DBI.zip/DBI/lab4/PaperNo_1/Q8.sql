create proc proc_product_location 
@productid int, @numberOfLocation int output
as
begin
	set @numberOfLocation = (
	
		SELECT   COUNT(LocationID) 
		FROM         ProductInventory
		GROuP BY ProductID
		HAVING ProductID = @productid

	)

	if @numberOfLocation is null
	begin
		set @numberOfLocation = 0
	end
end



