/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedstack;


/**
 *
 * @author asus
 */
public class Stack {

    Node top;

    public Stack() {
        top = null;
    }

    public boolean isEmpty() {
        return top == null;

    }

    public void push(Object x) {
        top = new Node(x, top);
    }

    public Object peek() {
        if (isEmpty()) {
            return null;
        }
        return top.info;
    }

    public Object pop() {
        if (isEmpty()) {
            return null;
        }
        Object x = top.info;
        top = top.next;
        return x;
    }

    public void clear() {
        top = null;
    }

    public boolean checkParentheses(String s) {
        clear();
        for (char c : s.toCharArray()) {
            if (c == '(' || c == '{' || c == '[') {
                push(c);
            } else {
                if (isEmpty()) {
                    return false;
                }
                char t = (char) pop();
                if (c == '(' && t != ')') {
                    return false;
                }
                if (c == '[' && t != ']') {
                    return false;
                }
                if (c == '{' && t != '}') {
                    return false;
                }

            }
        }
        return isEmpty();
    }

    public int evaluatePostfix(String s)  {
        clear();
        String[] str = s.split(" ");
        for (String i : str) {
            System.out.println(i);
        }
        for (String i : str) {
            
            if (i.matches("\\d+")) {
                push(Integer.parseInt(i));
            } else if (i.matches("[\\+\\-*/]")) {
                push(cal(i));
            }
        }
        return (int) peek();
    }

    public int cal(String i) {
        int num1 = (int) pop(), num2 = (int) pop();
        switch (i) {
            case "+":
                return num2 + num1;
            case "-":
                return num2 - num1;
            case "*":
                return num2 * num1;
            case "/":
                return num2 / num1;
            default:
                throw new AssertionError();
        }
    }

    public String convertToPostfix(String infix) {
        clear();
        String postfix = "";
        for (char c : infix.toCharArray()) {
            if (c == ' ') continue;
            if (Character.isLetterOrDigit(c)) {
                postfix += c;
            }else if ( c == '('){
                push(c);
            }else if (c == ')'){
                while (!isEmpty() && (char)peek() != '('){
                    postfix += (char)pop();
                }
                pop();
            }
            else {
                while ( !isEmpty() && Prec(c) <= Prec((char)peek())){
                    postfix += (char)pop();
                }
                push(c);
            }
        }
        while (!isEmpty()){
            postfix += (char)pop();
        }
        return postfix;
    }

    public int Prec(char c) {
        switch (c) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            default:
                return -1;
        }
    }
}
