/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doublelinkedlist;

/**
 *
 * @author asus
 */
public class Node {
    int info;
    Node next;
    Node prev;
    Node(){
        next = null;
        prev = null;
    }
    Node(int info){
        this.info = info;
        next = null;
        prev = null;
    }
    Node(int info, Node next, Node prev){
        this.info = info;
        this.next = next;
        this.prev = prev;
    }
    
    
}
