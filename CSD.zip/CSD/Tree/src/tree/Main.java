/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tree;

/**
 *
 * @author asus
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Btree b = new Btree();
        int[] a = {1,2,3,4,5,6,7,8,9,10, 11, 12};
        b.createBtree( a );
//        System.out.println(b.level(a));
//        System.out.print(" breath: ");
//        b.breadth();
//        System.out.print(" \npreorder: ");
//        b.preOrder(b.root);
//        System.out.print(" \ninorder: ");
//        b.inOrder(b.root);
//        System.out.print(" \npostorder: ");
//        b.postOrder(b.root);
        System.out.println(b.countLeaf(b.root));
    }
    
}
